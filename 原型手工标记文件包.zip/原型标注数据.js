window.PROTOTYPE_ANNOTATIONS = [
  {
    "id": "misreport-settings:system:01",
    "context": "误报类型配置.html::page",
    "page": "误报类型配置.html",
    "title": "导航与用途",
    "body": "参数配置与查处管理、责任区域管理、报警处置移动端同级；误报类型配置为参数配置下二级菜单，用于维护复核误报原因，不新增算法类型。",
    "updated": "2026-10-19",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".page-head",
    "point": {
      "rx": 0.35,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "misreport-settings:system:02",
    "context": "误报类型配置.html::page",
    "page": "误报类型配置.html",
    "title": "默认字典",
    "body": "首次使用提供14项误报原因，每项含稳定ID、名称和说明。配置未保存时读取默认字典；显式删除全部类型后保留空列表，不自动恢复默认值。",
    "updated": "2026-10-18",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": "table thead th",
    "point": {
      "rx": 0.6,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "targetText": "误报类型",
    "anchorVersion": 2
  },
  {
    "id": "misreport-settings:system:03",
    "context": "误报类型配置.html::page",
    "page": "误报类型配置.html",
    "title": "查询与列表",
    "body": "关键词匹配类型名称和说明，实时过滤并显示命中数量。列表展示序号、误报类型、说明和编辑/删除操作；无记录时显示空态。",
    "updated": "2026-10-18",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": "#search",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "misreport-settings:system:04",
    "context": "misreport-settings:dialog:editor",
    "page": "误报类型配置.html",
    "title": "新增与编辑弹窗",
    "body": "新增按钮打开新增弹窗，编辑操作打开当前记录。名称必填、去除首尾空格后不可为空、最多40字符、不可与其他记录重名；说明选填、最多200字符。保存成功后关闭弹窗并刷新列表；失败保留输入并提示。取消或Esc关闭，不保存。",
    "updated": "2026-10-18",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": "#editorTitle",
    "template": true,
    "point": {
      "rx": 0.65,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "misreport-settings:system:05",
    "context": "misreport-settings:dialog:delete",
    "page": "误报类型配置.html",
    "title": "删除确认弹窗",
    "body": "点击删除打开确认框，显示类型名称和删除后的下拉影响。取消保留记录；确认删除后保存并刷新列表；存储失败在弹窗显示错误。删除后复核下拉不再提供该项，不代表已实现历史复核记录迁移。",
    "updated": "2026-10-18",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": "#removeDialog h2",
    "template": true,
    "point": {
      "rx": 0.65,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "misreport-settings:system:06",
    "context": "误报类型配置.html::page",
    "page": "误报类型配置.html",
    "title": "与复核下拉联动",
    "body": "配置页与复核页使用同一浏览器本地字典。新增、修改、删除后，复核页在重新打开、切回窗口或收到存储变化时重新读取选项。选中项使用稳定ID，更名保留对应ID；已删除的选中项清空。",
    "updated": "2026-10-18",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T05:18:12.920514+00:00",
    "target": null,
    "anchorVersion": 2
  },
  {
    "id": "misreport-settings:system:07",
    "context": "误报类型配置.html::page",
    "page": "误报类型配置.html",
    "title": "持久化边界",
    "body": "配置保存在本机浏览器本地存储，未接入后端或跨设备共享；浏览器策略、不同来源或清除存储可能影响恢复。读取与写入失败均有错误提示。",
    "updated": "2026-10-18",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": null,
    "anchorVersion": 2
  },
  {
    "id": "alarm-center:system:01",
    "context": "AI隐患核查.html::page",
    "page": "AI隐患核查.html",
    "title": "页面用途与来源隔离",
    "body": "AI报警中心只展示AI识别报警，消防设备报警不进入列表、今日与全部数量、筛选、详情及复核。全局待复核提醒同样排除消防。来源依据明确来源字段及既有设备／演示ID映射判定，不按“消防通道堵塞”“烟雾”等事件名称误判。\n已确认信号规则：同摄像头稳定ID＋同来源事件类型，从首次报警起在待复核、待接收、待处置期间合并；只保留一个未结束事件及一份确认违规任务。保留首次／最近时间和有效信号次数，重传去重，不重置计时或重复短信。已处置、误报、计划内事件结束后新有效信号重新生成待复核事件。5秒一次是示例频率，不是合并窗口。真实信号接入与服务端合并尚待实现。\n已确认信号规则：同摄像头稳定ID＋同来源事件类型，从首次报警起在待复核、待接收、待处置期间合并；只保留一个未结束事件及一份确认违规任务。保留首次／最近时间和有效信号次数，重传去重，不重置计时或重复短信。已处置、误报、计划内事件结束后新有效信号重新生成待复核事件。5秒一次是示例频率，不是合并窗口。真实信号接入与服务端合并尚待实现。",
    "updated": "2026-10-24",
    "source": "用户2026年10月24日确认及最新版需求规格说明书",
    "checked": "2026-10-24",
    "system": true,
    "updatedAt": "2026-10-24T18:00:01+08:00",
    "target": "main > header",
    "point": {
      "rx": 0.28,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "alarm-center:system:02",
    "context": "AI隐患核查.html::page",
    "page": "AI隐患核查.html",
    "title": "今日与全部报警",
    "body": "今日报警按当日日期过滤；全部报警包含历史记录。Tab显示实际记录数。今日不显示时间筛选，全部显示单个起止时间选择器，默认最近一个月；切回今日不应用全部页的时间限制。",
    "updated": "2026-10-18",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": "#alarmScopeTabs",
    "point": {
      "rx": 0.4,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "alarm-center:system:03",
    "context": "AI隐患核查.html::page",
    "page": "AI隐患核查.html",
    "title": "筛选与展开",
    "body": "默认只显示首行条件，其余条件通过展开/收起切换。支持违规事件类型、复核状态、复核结果、复核是否超期及关键词组合筛选。切换与输入后更新列表、统计和空态。",
    "updated": "2026-10-18",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": "#alarmFilterToggle",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "alarm-center:system:04",
    "context": "AI隐患核查.html::page",
    "page": "AI隐患核查.html",
    "title": "统计口径",
    "body": "报警总数、待复核、确认违规、误报、计划内事件按筛选结果统计。复核完成率=已复核/总数；准确率=确认违规/(确认违规+误报)，计划内事件不参与准确率分母。\n信号合并后AI报警、任务和完成量按事件计；累计信号次数单独记录，不按信号、通知或收件人数放大统计。\n信号合并后AI报警、任务和完成量按事件计；累计信号次数单独记录，不按信号、通知或收件人数放大统计。",
    "updated": "2026-10-24",
    "source": "用户2026年10月24日确认及最新版需求规格说明书",
    "checked": "2026-10-24",
    "system": true,
    "updatedAt": "2026-10-24T18:00:01+08:00",
    "target": "#alarmStats",
    "point": {
      "rx": 0.55,
      "ry": 0.15
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "alarm-center:system:05",
    "context": "AI隐患核查.html::page",
    "page": "AI隐患核查.html",
    "title": "列表与等级",
    "body": "显示报警ID、事件类型、时间、设备、置信度、一级至四级报警等级、责任区域、责任人、照片、复核状态、结果、复核人、复核时间及复核超期。等级按事件类型配置映射；操作列固定在右侧。",
    "updated": "2026-10-18",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": "#alarmRecordsTable th",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "targetText": "报警等级",
    "anchorVersion": 2
  },
  {
    "id": "alarm-center:system:06",
    "context": "AI隐患核查.html::page",
    "page": "AI隐患核查.html",
    "title": "复核超期规则",
    "body": "复核时限来自基础配置，默认5分钟。未复核从报警计时到当前；已复核计算到复核时间。超过时限显示具体超期秒数或分钟，等于时限不超期。列表支持按是否超期筛选。",
    "updated": "2026-10-18",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": "#alarmRecordsTable th",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "targetText": "复核超期",
    "anchorVersion": 2
  },
  {
    "id": "alarm-center:system:07",
    "context": "AI隐患核查.html::page",
    "page": "AI隐患核查.html",
    "title": "详情与复核跳转",
    "body": "来源为列表或全局报警提醒；详情通过alarmId打开当前报警详情抽屉，复核通过alarmId进入AI报警复核页。已复核仅提供详情，待复核还提供复核。",
    "updated": "2026-10-18",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": "#alarmRecordsTable a,#alarmRecordsTable button",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "targetText": "复核",
    "anchorVersion": 2
  },
  {
    "id": "alarm-center:system:08",
    "context": "alarm-center:detail:alarmId",
    "page": "AI隐患核查.html",
    "title": "基本信息与证据",
    "body": "标题为AI报警详情。基本信息保留报警ID、事件类型、时间、设备、置信度、等级、责任区域、责任人、复核超期；不展示违章人员及四个复核字段，不提供查看位置。照片可查看，视频显示封面和播放按钮；无视频源时提示暂无可播放视频。",
    "updated": "2026-10-18",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "template": true,
    "target": "[data-detail-field=\"id\"]",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "alarm-center:system:09",
    "context": "alarm-center:detail:alarmId",
    "page": "AI隐患核查.html",
    "title": "复核结果展示",
    "body": "统一结果卡片。确认违规：结果、事件类型、报警等级、备注、复核人、复核时间；误报：结果、误报类型、备注、复核人、复核时间；计划内事件：结果、备注、复核人、复核时间。取当前报警记录，缺失内容显示—。",
    "updated": "2026-10-18",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "template": true,
    "target": "#timelineContainer",
    "point": {
      "rx": 0.5,
      "ry": 0.1
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "alarm-center:system:10",
    "context": "alarm-center:notification:alarmId",
    "page": "AI隐患核查.html",
    "title": "全局新报警提醒",
    "body": "各业务页共用右下角提醒。当前演示先显示第一条，5秒后第二条，停止轮播；两条分别于出现10秒后消失，最多2条，最新在底部。单条可关闭。有提醒时隐藏数量悬浮入口，无提醒时恢复。",
    "updated": "2026-10-18",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "template": true,
    "target": ".gac-toast .gac-head",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "alarm-center:system:11",
    "context": "alarm-center:pending-drawer",
    "page": "AI隐患核查.html",
    "title": "提醒与待复核抽屉",
    "body": "提醒名称右侧显示待复核状态，等级使用语义颜色；头部关闭左侧为待复核(数量...)入口。入口或悬浮数量打开全部待复核抽屉；详情和复核分别携带当前alarmId跳转；关闭、Esc恢复页面。",
    "updated": "2026-10-18",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "template": true,
    "target": ".gac-drawer h2,.gac-drawer h3",
    "point": {
      "rx": 0.7,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "alarm-center:system:12",
    "context": "AI隐患核查.html::page",
    "page": "AI隐患核查.html",
    "title": "当前实现边界",
    "body": "新增报警事件入口可接收数据，但演示计时不等于真实后台推送。报警中心原型的分页、导出仍为既有演示控件，不宣称后端分页或真实导出。",
    "updated": "2026-10-18",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": null,
    "anchorVersion": 2
  },
  {
    "id": "alarm-review:system:01",
    "context": "AI识别的违章复核.html::page",
    "page": "AI识别的违章复核.html",
    "title": "页面入口",
    "body": "由待复核报警进入，携带alarmId并加载对应演示记录；复核超期显示与基础配置一致。返回入口指向AI报警中心。",
    "updated": "2026-10-18",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": "a[aria-label=\"返回AI报警中心\"]",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "alarm-review:system:02",
    "context": "AI识别的违章复核.html::page",
    "page": "AI识别的违章复核.html",
    "title": "信息与证据",
    "body": "显示当前报警ID、事件类型、报警时间、设备、置信度、等级、责任区域、责任人、复核超期。照片随记录变化；监控播放和目标框仍包含演示表现，不视为真实视频分析能力。",
    "updated": "2026-10-18",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": "img[alt=\"工业厂房作业区域全景\"]",
    "point": {
      "rx": 0.5,
      "ry": 0.15
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "alarm-review:system:03",
    "context": "AI识别的违章复核.html::page",
    "page": "AI识别的违章复核.html",
    "title": "复核结果选择",
    "body": "单选误报、确认违规、计划内事件，默认确认违规。切换显示对应字段，选择与未选择状态用颜色区别。\n仅AI确认违规创建任务并按责任区域匹配人员发短信；待复核、误报、计划内事件及消防均不发该处置短信。同摄像头同来源类型的未结束报警后续信号不触发重复核警或任务。\n仅AI确认违规创建任务并按责任区域匹配人员发短信；待复核、误报、计划内事件及消防均不发该处置短信。同摄像头同来源类型的未结束报警后续信号不触发重复核警或任务。",
    "updated": "2026-10-24",
    "source": "用户2026年10月24日确认及最新版需求规格说明书",
    "checked": "2026-10-24",
    "system": true,
    "updatedAt": "2026-10-24T18:00:01+08:00",
    "target": "[data-review-result=\"确认违规\"]",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "alarm-review:system:04",
    "context": "AI识别的违章复核.html::page",
    "page": "AI识别的违章复核.html",
    "title": "误报填写",
    "body": "显示误报类型及通用备注。误报类型使用误报类型配置字典；新增、修改、删除后复核选项同步读取。",
    "updated": "2026-10-18",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": "#misreportType",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "alarm-review:system:05",
    "context": "AI识别的违章复核.html::page",
    "page": "AI识别的违章复核.html",
    "title": "确认违规与等级取高",
    "body": "确认违规必须选择有效事件类型及报警等级。最终报警及上报取事件类型与摄像头配置中较高等级，一级最高、四级最低；未配置摄像头等级时按事件类型。仅AI核警确认违规后生成一份处置任务并触发责任区域全员短信，误报、计划内事件不生成任务及处置短信。",
    "updated": "2026-10-24",
    "source": "用户2026年10月24日确认及最新版需求规格说明书",
    "checked": "2026-10-24",
    "system": true,
    "updatedAt": "2026-10-24T18:00:01+08:00",
    "target": "#reviewAlarmLevel",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "alarm-review:system:06",
    "context": "AI识别的违章复核.html::page",
    "page": "AI识别的违章复核.html",
    "title": "计划内事件",
    "body": "展示计划内事件结果及通用备注，不强制填写与该分支无关的事件类型或误报原因。",
    "updated": "2026-10-18",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": "[data-review-result=\"计划内事件\"]",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "alarm-review:system:07",
    "context": "AI识别的违章复核.html::page",
    "page": "AI识别的违章复核.html",
    "title": "提交边界",
    "body": "常规入口保留静态复核页面与结果选择；带监测大屏来源参数进入时，加载指定报警并启用共享数据提交、校验、确认和返回。不要将常规静态按钮视为已接入真实后端；大屏当前按钮优先使用本页内复核弹窗。",
    "updated": "2026-10-22",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": "button",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "targetText": "提交复核结果",
    "anchorVersion": 2
  },
  {
    "id": "case-management:system:01",
    "context": "隐患违章管理-违章查处.html::page",
    "page": "隐患违章管理-违章查处.html",
    "title": "页面入口与报警来源",
    "body": "查处管理同时展示AI识别报警和消防设备报警。AI仅已复核且确认违规进入接收处置流程；消防直接展示外部同步的待处置／已处置状态，不依赖AI复核字段，不提供本地接收、复核、处置填写或状态修改。",
    "updated": "2026-10-22",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".case-filters > div:first-child label",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "case-management:system:02",
    "context": "隐患违章管理-违章查处.html::page",
    "page": "隐患违章管理-违章查处.html",
    "title": "筛选区",
    "body": "增加报警来源筛选，可选择全部来源、AI识别、消防设备。切换来源清空事件、等级、状态和超期旧条件并回到第一页。消防模式只保留报警名称、时间、状态、责任区域及关键词等适用筛选，不显示报警等级、复核超期及处置超期；消防状态只有待处置、已处置。重置恢复全部来源。",
    "updated": "2026-10-22",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".case-filter-footer button",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "targetText": "展开",
    "anchorVersion": 2
  },
  {
    "id": "case-management:system:03",
    "context": "隐患违章管理-违章查处.html::page",
    "page": "隐患违章管理-违章查处.html",
    "title": "统计卡片口径",
    "body": "查处总数、待接收、已处置及待处置按当前筛选记录计算；消防仅参与状态展示数量，不参与AI一级报警、AI超期及AI处置完成率。AI处置完成率仅以当前筛选的AI确认违规记录为分母，无AI样本显示—。",
    "updated": "2026-10-22",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".case-metrics",
    "point": {
      "rx": 0.5,
      "ry": 0.2
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "case-management:system:04",
    "context": "隐患违章管理-违章查处.html::page",
    "page": "隐患违章管理-违章查处.html",
    "title": "列表字段顺序",
    "body": "列表首列为报警来源，后续为处置状态、处置人（责任人）、联系方式、处置超期、报警ID、报警名称、报警时间、设备名称、置信度、报警等级、责任区域、报警照片、复核人、复核时间、复核超期、违规人员、接收时间、处置时间、处置周期及操作。全部来源时消防的AI专属字段为—；只看消防时隐藏这些列。人员信息优先取完成或接收记录，不以违规人员代替处置人。导出增加来源并与当前筛选保持一致。",
    "updated": "2026-10-22",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".case-table th",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "targetText": "报警时间",
    "anchorVersion": 2
  },
  {
    "id": "case-management:system:05",
    "context": "隐患违章管理-违章查处.html::page",
    "page": "隐患违章管理-违章查处.html",
    "title": "列表操作与导出",
    "body": "列表增加报警来源列，全部来源混排时消防的AI专属字段显示—；只看消防时隐藏等级、复核、置信度、违规人员、接收及处置填写相关列。AI记录按状态提供接收、处置、详情与电话介入；消防只提供详情及待处置时的值守电话记录。导出沿用当前筛选和来源字段，不导出消防旧AI字段。",
    "updated": "2026-10-22",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".case-table-top button",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "targetText": "导出",
    "anchorVersion": 2
  },
  {
    "id": "case-management:system:06",
    "context": "隐患违章管理-违章查处.html::page",
    "page": "隐患违章管理-违章查处.html",
    "title": "任务接收与负责人锁定",
    "body": "已确认规则：AI核警确认违规后，按报警摄像头位置和责任区域配置向全部匹配安管人员发送短信，生成一份任务。第一位成功接收者成为唯一主要负责人及最终处置人，其他人只可查看，不可再次接收、编辑或提交。多人同时接收由服务端保证仅一人成功；重复请求不重复记录。接收失败保持原状态，成功记录身份和时间，从接收起计算处置期限。当前静态原型的浏览器演示存储不代表真实多人并发、权限及短信已接入。",
    "updated": "2026-10-24",
    "source": "用户2026年10月24日确认及最新版需求规格说明书",
    "checked": "2026-10-24",
    "system": true,
    "updatedAt": "2026-10-24T18:00:01+08:00",
    "target": ".case-table tbody button",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "targetText": "接收处置",
    "anchorVersion": 2
  },
  {
    "id": "case-management:system:07",
    "context": "隐患违章管理-违章查处.html::page",
    "page": "隐患违章管理-违章查处.html",
    "title": "处置超期与周期",
    "body": "处置超期从接收开始，到完成或当前时间，减去基础配置时限，未超期或未接收显示否。默认30分钟。处置周期只保留一项，定义为报警时间到最终完成时间；未完成显示—，不再使用已闭环和闭环周期文案。",
    "updated": "2026-10-18",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".case-table th",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "targetText": "处置超期",
    "anchorVersion": 2
  },
  {
    "id": "case-management:system:08",
    "context": "case-management:detail:alarmId",
    "page": "隐患违章管理-违章查处.html",
    "title": "详情分支与状态展示",
    "body": "AI详情沿用查处详情／处置记录双Tab及既有字段。消防使用独立详情，仅展示报警ID、来源、名称、时间、设备、责任区域、外部处置状态和状态更新时间及电话记录；无等级、复核结果、接收或处置表单。外部记录变化后刷新状态，缺失更新时间显示—，不虚构本地完成时间。",
    "updated": "2026-10-22",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "template": true,
    "target": ".case-section-title",
    "point": {
      "rx": 0.7,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "case-management:system:09",
    "context": "case-management:process:alarmId",
    "page": "隐患违章管理-违章查处.html",
    "title": "处置表单",
    "body": "点击处置只显示处理表单，不显示报警基本信息和复核结果。先选择违规人员，再填写处理经过描述和整改措施，上传处理照片；不再填写考核金额或记分。",
    "updated": "2026-10-18",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "template": true,
    "target": ".case-section-title",
    "point": {
      "rx": 0.65,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "targetText": "选择违规人员",
    "anchorVersion": 2
  },
  {
    "id": "case-management:system:10",
    "context": "case-management:process:alarmId",
    "page": "隐患违章管理-违章查处.html",
    "title": "人员与历史分布",
    "body": "违规人员必选，选项格式姓名（手机号），同名不同手机号独立统计。演示号码非真实联系信息。选人后显示历史次数、最后一次违规时间与类型。横向条形图按次数降序，最多5行，其余滚动；不再显示逐条历史列表。历史排除当前报警。",
    "updated": "2026-10-18",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "template": true,
    "target": ".case-history",
    "point": {
      "rx": 0.6,
      "ry": 0.1
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "case-management:system:11",
    "context": "case-management:process:alarmId",
    "page": "隐患违章管理-违章查处.html",
    "title": "处理字段与照片",
    "body": "经过描述、整改措施必填，各最多500字；照片最多3张，每张不超过2MB且为图片。提交前校验并确认，保存失败保留输入，成功更新状态和统计，刷新恢复；处置人默认沿用接收人。",
    "updated": "2026-10-18",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "template": true,
    "target": ".case-section-title",
    "point": {
      "rx": 0.7,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "targetText": "处理结果",
    "anchorVersion": 2
  },
  {
    "id": "case-management:system:12",
    "context": "隐患违章管理-违章查处.html::page",
    "page": "隐患违章管理-违章查处.html",
    "title": "AI电话督办与消防超期电话",
    "body": "AI未完成任务可记录催接收或催处置。消防只同步消防管家最新待处置／已处置状态，不产生本地AI接收、处置或短信；消防仍未处置且超出处置期限时可电话介入，记录联系对象、内容、结果、值守人员与时间，电话不改外部状态。已处置停止新增电话，历史可查。不自动拨号。消防超期依据优先取外部标识或截止时间；缺失时需确认消防时限与起点，不能套用AI接收后1800秒。当前页面演示与正式规则的差异需另行实现。",
    "updated": "2026-10-24",
    "source": "用户2026年10月24日确认及最新版需求规格说明书",
    "checked": "2026-10-24",
    "system": true,
    "updatedAt": "2026-10-24T18:00:01+08:00",
    "target": ".case-table tbody button",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "targetText": "电话介入",
    "anchorVersion": 2
  },
  {
    "id": "case-management:system:13",
    "context": "case-management:phone-entry:alarmId:stage",
    "page": "隐患违章管理-违章查处.html",
    "title": "介入填写与保存",
    "body": "联系对象、催促内容、联系结果必填，分别最多30、500、100字。保存附介入阶段、值守人员、时间，追加存储；失败提示并保留输入。取消不保存；已处置禁止再介入。",
    "updated": "2026-10-18",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "template": true,
    "target": "textarea,.n-input",
    "point": {
      "rx": 0.5,
      "ry": 0.2
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "case-management:system:14",
    "context": "case-management:phone-history:alarmId:stage",
    "page": "隐患违章管理-违章查处.html",
    "title": "已电话介入查看",
    "body": "当前阶段已有介入时按钮改为已电话介入；点击780px宽弹窗，紧凑时间轴展示阶段、时间、值守人员、联系对象、内容和结果，多条向下滚动。再次介入进入录入。阶段从催接收变为催处置后独立判断。第一条演示保留可介入入口。",
    "updated": "2026-10-18",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "template": true,
    "target": ".case-kv",
    "point": {
      "rx": 0.5,
      "ry": 0.1
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "case-management:system:15",
    "context": "case-management:timeline:alarmId",
    "page": "隐患违章管理-违章查处.html",
    "title": "处置记录时间轴",
    "body": "展示AI触发报警、人工复核完成、已接收处置、处置完成，电话节点按真实记录时间插入；不再单列推送报警中心或转入查处管理。每行一个字段，报警和处理照片可放大。未发生节点无虚构完成时间。\n新增业务留痕包括信号合并摘要、责任区域匹配人员、逐人短信状态和回执、唯一成功接收人及最终完成结果。短信提交发送不等于送达，失败保留任务及原因；不得把上述正式服务描述为已在静态原型实现。\n新增业务留痕包括信号合并摘要、责任区域匹配人员、逐人短信状态和回执、唯一成功接收人及最终完成结果。短信提交发送不等于送达，失败保留任务及原因；不得把上述正式服务描述为已在静态原型实现。",
    "updated": "2026-10-24",
    "source": "用户2026年10月24日确认及最新版需求规格说明书",
    "checked": "2026-10-24",
    "system": true,
    "updatedAt": "2026-10-24T18:00:01+08:00",
    "template": true,
    "target": ".n-timeline",
    "point": {
      "rx": 0.5,
      "ry": 0.1
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "case-management:system:16",
    "context": "隐患违章管理-违章查处.html::page",
    "page": "隐患违章管理-违章查处.html",
    "title": "演示与持久化",
    "body": "待接收、待处置、已处置均有示例。新增共享示例含两条待处置、两条已处置，覆盖按时与超期，默认处置人员张安全；电脑端和移动端读取同一批演示报警与操作记录。示例仅首次补充，不覆盖已保存结果。刘刚另有26条、8类人员历史示例，仅用于历史分布，不新增报警任务。保存仅限同一浏览器存储环境，未接后端鉴权。",
    "updated": "2026-10-19",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": null,
    "anchorVersion": 2
  },
  {
    "id": "basic-settings:system:01",
    "context": "基础配置.html::page",
    "page": "基础配置.html",
    "title": "配置与布局",
    "body": "参数配置下二级菜单。卡片适应内容区宽度，输入与单位区域固定360px、靠左，不随卡片铺满。仅配置复核时限和处置时限，等级映射已移至独立页面。",
    "updated": "2026-10-18",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".settings-card .case-title",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "basic-settings:system:02",
    "context": "基础配置.html::page",
    "page": "基础配置.html",
    "title": "时限字段",
    "body": "复核默认5分钟，处置默认30分钟；单位支持分钟或秒，数值必须为正整数，换算后不超过365天。复核自报警起算，处置自接收起算；等于时限不算超期。",
    "updated": "2026-10-18",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".settings-section .settings-row",
    "point": {
      "rx": 0.65,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "basic-settings:system:03",
    "context": "基础配置.html::page",
    "page": "基础配置.html",
    "title": "保存与联动",
    "body": "点击保存统一校验，保存到浏览器；成功提示，失败提示。报警列表、详情、复核页面和查处管理读取同一时限规则，统计与是否超期同步，不代表服务器全局配置。",
    "updated": "2026-10-18",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".settings-card button",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "targetText": "保存配置",
    "anchorVersion": 2
  },
  {
    "id": "event-level-settings:system:01",
    "context": "报警等级配置.html::page",
    "page": "报警等级配置.html",
    "title": "事件与摄像头等级",
    "body": "支持按22种违规事件类型配置等级；也可通过添加摄像头弹窗批量选择摄像头加入配置列表，再逐台指定等级。摄像头初始不配置等级，不要求覆盖全部摄像头；同一摄像头不可重复添加，支持修改和确认删除。",
    "updated": "2026-10-24",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-24T18:00:00+08:00",
    "target": ".basic-level-table tbody tr:first-child .n-base-selection",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "event-level-settings:system:02",
    "context": "报警等级配置.html::page",
    "page": "报警等级配置.html",
    "title": "摄像头筛选与批量添加",
    "body": "按摄像头配置内容区右上角为添加摄像头按钮。主列表支持摄像头名称、所属区域级联下拉（楼栋→楼层→区域，可仅选楼栋或楼层）与报警等级组合筛选；等级仅一级至四级，无未配置等级选项。列表含序号、报警摄像头、所属区域完整路径、报警等级、删除操作。添加弹窗保持楼栋、楼层、区域分项筛选，支持只筛楼栋或楼层，并可按名称及编号搜索；列表多选、全选当前结果，跨筛选保留勾选，已添加摄像头禁止重复勾选。确认加入主列表后逐台选择等级，未选等级不能保存；取消不添加。",
    "updated": "2026-10-24",
    "source": "用户2026年10月24日确认及最新版需求规格说明书",
    "checked": "2026-10-24",
    "system": true,
    "updatedAt": "2026-10-24T18:00:01+08:00",
    "target": ".case-table-top .n-input",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "event-level-settings:system:03",
    "context": "报警等级配置.html::page",
    "page": "报警等级配置.html",
    "title": "保存与等级取高",
    "body": "保存配置统一保存事件类型及摄像头等级，添加、修改和删除在保存后生效，刷新保留。一级最高、四级最低；报警事件等级与上报等级均取事件类型等级和摄像头等级中较高者，未配置摄像头则使用事件类型等级。例如摄像头A一级、事件类型二级，最终报警和上报均为一级。当前为静态原型，未连接真实上报接口。",
    "updated": "2026-10-24",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-24T09:00:00+08:00",
    "target": "button",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "targetText": "保存配置",
    "anchorVersion": 2
  },
  {
    "id": "mobile-disposal:system:01",
    "context": "报警处置移动端.html::page",
    "page": "报警处置移动端.html",
    "title": "页面入口与用户",
    "body": "由左侧报警处置移动端一级菜单进入独立HTML。手机全屏，电脑按手机宽度预览，不嵌入电脑端导航。默认演示处置人员张安全。已复核且确认违规的报警才进入任务池；误报、计划内事件不进入。未接收按指定人员过滤，未指定时为可接收任务；已接收或完成按记录中的处置人过滤。角色与任务分配均为静态演示，不代表后端权限。\n短信进入小程序对应任务，已绑定且会话有效直接进入；首次或身份失效先验证手机号并绑定，再返回原任务。转发链接不赋予权限；已被他人接收则只读，已完成进入结果，失效链接明确提示。真实短信、小程序鉴权及跨设备权限尚待接入。\n短信进入小程序对应任务，已绑定且会话有效直接进入；首次或身份失效先验证手机号并绑定，再返回原任务。转发链接不赋予权限；已被他人接收则只读，已完成进入结果，失效链接明确提示。真实短信、小程序鉴权及跨设备权限尚待接入。",
    "updated": "2026-10-24",
    "source": "用户2026年10月24日确认及最新版需求规格说明书",
    "checked": "2026-10-24",
    "system": true,
    "updatedAt": "2026-10-24T18:00:01+08:00",
    "target": ".top .bar h1",
    "point": {
      "rx": 0.75,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "mobile-disposal:system:02",
    "context": "报警处置移动端.html::page",
    "page": "报警处置移动端.html",
    "title": "菜单分工与状态",
    "body": "底部处置任务仅显示待接收、待处置；处置记录只显示本人已处置报警。处置任务Tab为全部、待接收、待处置，无已处置Tab；全部仅合并两种未完成状态。顶部统计为待办总数、待接收、待处置，待办总数等于两项之和。已处置不参与待办统计。\n正式任务权限：匹配人员可见待接收任务，首位成功接收者进入本人待处置，其他人员仍可查看进度但不再计作本人处置待办；只有锁定接收人能填写和提交。\n正式任务权限：匹配人员可见待接收任务，首位成功接收者进入本人待处置，其他人员仍可查看进度但不再计作本人处置待办；只有锁定接收人能填写和提交。",
    "updated": "2026-10-24",
    "source": "用户2026年10月24日确认及最新版需求规格说明书",
    "checked": "2026-10-24",
    "system": true,
    "updatedAt": "2026-10-24T18:00:01+08:00",
    "target": ".bottom",
    "point": {
      "rx": 0.35,
      "ry": 0.25
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "mobile-disposal:system:03",
    "context": "报警处置移动端.html::page",
    "page": "报警处置移动端.html",
    "title": "排序与筛选",
    "body": "处置任务先排待接收，再排待处置。同状态按接收时间倒序；未接收无接收时间，按报警通知时间倒序，缺失时间排后，同时间以报警ID稳定排序。支持关键词匹配报警ID、事件类型、责任区域、设备、原责任人及报警等级筛选。统计按本人任务全量计算，列表数量按当前筛选计算。处置记录未另设接收时间排序，沿用报警时间倒序。",
    "updated": "2026-10-19",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".search",
    "point": {
      "rx": 0.8,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "mobile-disposal:system:04",
    "context": "报警处置移动端.html::page",
    "page": "报警处置移动端.html",
    "title": "列表卡片与空态",
    "body": "卡片展示报警等级、事件类型、状态、报警照片、责任区域、设备、报警时间与处置时限提示。待接收显示查看并接收，待处置显示去处置，均先进入报警详情。处置记录显示查看结果。无结果提示调整筛选或等待新通知。",
    "updated": "2026-10-19",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".task:first-child .task-title",
    "point": {
      "rx": 0.75,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "mobile-disposal:system:05",
    "context": "mobile-disposal:detail:alarmId",
    "page": "报警处置移动端.html",
    "title": "详情顶部闭环",
    "body": "详情顶部为报警通知→接收任务→处置完成。各节点下显示日期与时分秒；接收前显示待接收，完成前显示待完成。历史已完成但无接收时间显示时间未记录，不虚构。报警通知优先读取独立通知时间；旧演示数据暂取复核完成时间。顶部不使用复核确认或提交处置作为节点名称。",
    "updated": "2026-10-19",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "template": true,
    "target": ".detail h2,.detail-title",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "mobile-disposal:system:06",
    "context": "mobile-disposal:detail:alarmId",
    "page": "报警处置移动端.html",
    "title": "报警详情字段与现场",
    "body": "报警信息展示报警时间、设备名称、责任区域、识别置信度及存在时的报警备注。不展示处置人、处置人联系方式或独立复核结果区块。报警现场分别展示报警图片、报警视频片段：图片点击放大；视频片段使用现场图封面和居中播放图标，仅静态占位，无播放与点击效果。",
    "updated": "2026-10-19",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "template": true,
    "target": ".detail img,.thumb",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "mobile-disposal:system:07",
    "context": "mobile-disposal:accept-confirm:alarmId",
    "page": "报警处置移动端.html",
    "title": "首位接收锁定与计时",
    "body": "全部相关安管人员收到任务短信，任务未被接收时均可尝试接收；第一位成功接收者为唯一主要负责人及最终处置人，其他收件人仅有查看权限。接收需确认，取消不写入；并发仅一人成功，其他人刷新为只读并显示接收人。处置从成功接收时开始计时，默认1800秒，读取基础配置，等于时限不超期；合并信号不重置时间。当前静态原型未证明跨设备接收锁定已实现。",
    "updated": "2026-10-24",
    "source": "用户2026年10月24日确认及最新版需求规格说明书",
    "checked": "2026-10-24",
    "system": true,
    "updatedAt": "2026-10-24T18:00:01+08:00",
    "template": true,
    "target": "button",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "targetText": "确认接收",
    "anchorVersion": 2
  },
  {
    "id": "mobile-disposal:system:08",
    "context": "mobile-disposal:process:alarmId",
    "page": "报警处置移动端.html",
    "title": "处置填写与历史分布",
    "body": "先接收才可填写。违规人员使用可搜索姓名（手机号）下拉，必选；选中后显示历史次数、最近一次违规时间及类型、违规类型横向条形图。历史排除当前任务，合并已有处置记录与人员专用示例；按次数降序，同次数按类型排序，最长条为最高次数。刘刚有26条8类基础历史，叠加已有记录后次数可增加。无历史显示空态，切换人员实时更新。当前移动端按姓名归并历史，电脑端按姓名手机号归一；同名多手机号精确隔离尚需统一，不能宣称已实现。",
    "updated": "2026-10-19",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "template": true,
    "target": ".case-history,.history",
    "point": {
      "rx": 0.5,
      "ry": 0.1
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "mobile-disposal:system:09",
    "context": "mobile-disposal:process:alarmId",
    "page": "报警处置移动端.html",
    "title": "必填字段与照片",
    "body": "处理经过描述、整改措施必填，去首尾空白后校验，各最多500字并显示字数。照片选填，最多3张，支持JPG、PNG、WebP，每张不超过2MB；可上传、移除、放大。非法类型或超限显示错误；读取中阻止提交。",
    "updated": "2026-10-19",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "template": true,
    "target": "textarea",
    "point": {
      "rx": 0.5,
      "ry": 0.2
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "mobile-disposal:system:10",
    "context": "mobile-disposal:process:alarmId",
    "page": "报警处置移动端.html",
    "title": "草稿保存与返回",
    "body": "保存草稿按报警ID保存人员、两项文字和照片；重新进入恢复。填写页返回会先保存草稿，成功后返回详情；失败保留表单并提示。此为当前实现，不是取消即丢弃。详情返回列表保留原菜单、Tab与筛选；切换底部菜单清空关键词和等级筛选。",
    "updated": "2026-10-19",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "template": true,
    "target": "button",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "targetText": "草稿",
    "anchorVersion": 2
  },
  {
    "id": "mobile-disposal:system:11",
    "context": "mobile-disposal:submit-confirm:alarmId",
    "page": "报警处置移动端.html",
    "title": "提交权限与完成回执",
    "body": "提交前校验当前用户就是唯一成功接收人、任务未完成，并校验必填及图片状态。只有接收人可以提交，其他短信收件人即使保留旧页面或持有链接也只可查看。成功保存处置人（成功接收者）、违规人员、经过、整改措施、照片和完成时间，清理草稿并显示回执；失败保留输入。完成结果仅一份，重复提交不能覆盖，完成后移出负责人待办，其他授权人员可查看结果。正式权限和并发校验需服务端实现。",
    "updated": "2026-10-24",
    "source": "用户2026年10月24日确认及最新版需求规格说明书",
    "checked": "2026-10-24",
    "system": true,
    "updatedAt": "2026-10-24T18:00:01+08:00",
    "template": true,
    "target": "button",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "targetText": "提交",
    "anchorVersion": 2
  },
  {
    "id": "mobile-disposal:system:12",
    "context": "mobile-disposal:timeline:alarmId",
    "page": "报警处置移动端.html",
    "title": "处置记录字段一致",
    "body": "详情中的处置记录Tab按电脑端时间轴展示。顶部显示当前状态、处置周期（报警到最终完成，未完成为—）。AI触发报警：报警ID、违规事件类型、报警等级、设备名称、责任区域、报警照片。人工复核完成：复核人、复核结果、备注说明、复核耗时、复核超期。接收：接收人、接收时间。完成：违规人员、处理经过描述、整改措施、处置人、接收处置时间、处置完成时间、处置周期、处理照片。电话介入：介入阶段、值守人员、联系对象、催促内容、联系结果。按时间插入，未发生节点展示状态且无虚构时间。此完整审计记录保留复核节点，区别于详情顶部三个面向处置人的简化节点。",
    "updated": "2026-10-19",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "template": true,
    "target": ".n-timeline",
    "point": {
      "rx": 0.5,
      "ry": 0.1
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "mobile-disposal:system:13",
    "context": "报警处置移动端.html::page",
    "page": "报警处置移动端.html",
    "title": "数据与实现边界",
    "body": "新增两条待处置、两条已处置共享示例，可继续处置且刷新保留。接收、处置、电话记录与电脑端共用本地存储；支持同源其他标签页变更及聚焦刷新。同一浏览器存储不等于跨设备同步，未接真实通知推送、后台服务、真实登录或移动端复核。浏览器file协议的存储隔离以实际环境为准。",
    "updated": "2026-10-19",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": null,
    "anchorVersion": 2
  },
  {
    "id": "responsibility-area:system:01",
    "context": "责任区域管理.html::page",
    "page": "责任区域管理.html",
    "title": "菜单与页面用途",
    "body": "责任区域管理一级菜单位于查处管理下、参数配置上。当前页面已实现，用于维护部门及人员管辖的楼栋、楼层、区域与视频，不再是空白占位。左侧组织树，右侧部门管辖与人员列表。以下按当前代码核对，不将本聊天未讨论的未来功能写为确认需求。",
    "updated": "2026-10-19",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".page-head",
    "point": {
      "rx": 0.35,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "responsibility-area:system:02",
    "context": "责任区域管理.html::page",
    "page": "责任区域管理.html",
    "title": "组织选择与部门范围",
    "body": "左侧可搜索组织或部门。选中部门显示自身范围；业务单位显示下属部门范围去重汇总，编辑部门范围按钮禁用。部门表格字段为楼栋/场所、楼层、管辖区域、关联视频、操作；视频按钮打开对应楼层已关联视频。",
    "updated": "2026-10-19",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".ra-org",
    "point": {
      "rx": 0.7,
      "ry": 0.08
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "responsibility-area:system:03",
    "context": "责任区域管理.html::page",
    "page": "责任区域管理.html",
    "title": "人员列表",
    "body": "选中组织及其下属部门的人员可按姓名、岗位、部门、手机号搜索。展示人员姓名与手机号、部门与岗位、已关联范围、操作。人员模式为跟随部门或独立配置；提供查看范围、编辑管辖范围。分页支持5、10、20人，切换组织、关键词或每页条数回到第一页。",
    "updated": "2026-10-19",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".ra-people .ra-section-title",
    "point": {
      "rx": 0.6,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "responsibility-area:system:04",
    "context": "responsibility-area:scope-editor:targetId",
    "page": "责任区域管理.html",
    "title": "编辑部门与人员范围",
    "body": "部门编辑直接配置范围；人员编辑可按部门继承或按个人独立配置。按部门显示只读继承范围；按个人显示楼栋/楼层/区域勾选树与关联视频，树支持级联、搜索、清空。部门或独立配置保存要求至少关联一个楼栋、楼层或区域；继承模式可保存空部门范围。保存前草稿不改变已生效数据。\n任务通知规则：核警确认违规后，根据报警摄像头位置及有效管辖范围解析全部相关安管人员；跟随部门／班组及个人独立范围按已有配置解析，场所包含与显式摄像头关联取并集。选班组全部成员则逐人短信通知，不只通知班组长；同人多范围匹配按稳定人员ID去重。首位成功接收人锁定负责人，其他人员只读；通知匹配不代表所有人都成为主要负责人。\n任务通知规则：核警确认违规后，根据报警摄像头位置及有效管辖范围解析全部相关安管人员；跟随部门／班组及个人独立范围按已有配置解析，场所包含与显式摄像头关联取并集。选班组全部成员则逐人短信通知，不只通知班组长；同人多范围匹配按稳定人员ID去重。首位成功接收人锁定负责人，其他人员只读；通知匹配不代表所有人都成为主要负责人。",
    "updated": "2026-10-24",
    "source": "用户2026年10月24日确认及最新版需求规格说明书",
    "checked": "2026-10-24",
    "system": true,
    "updatedAt": "2026-10-24T18:00:01+08:00",
    "template": true,
    "target": ".n-tree,.ra-tree",
    "point": {
      "rx": 0.5,
      "ry": 0.15
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "responsibility-area:system:05",
    "context": "responsibility-area:asset-picker:targetId:videos",
    "page": "责任区域管理.html",
    "title": "关联视频与查看",
    "body": "编辑中关联视频打开独立选择层，支持搜索、区域过滤、分页和当前页选择。区域内隐式关联视频不可重复手动勾选，计数去重。确认后仅更新编辑草稿，最终保存范围才生效。人员查看范围与查看视频为只读弹层，关闭返回来源界面。",
    "updated": "2026-10-19",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "template": true,
    "target": ".n-data-table,.ra-video-list",
    "point": {
      "rx": 0.5,
      "ry": 0.1
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "responsibility-area:system:06",
    "context": "responsibility-area:scope-editor:targetId",
    "page": "责任区域管理.html",
    "title": "关闭与保存",
    "body": "编辑抽屉关闭时检测修改；有修改先提示确认放弃。保存成功写入浏览器，关闭抽屉并提示；失败保留输入和错误。个人按部门模式随部门配置变化，独立配置保持个人范围。当前未与移动端报警派单建立真实权限联动。",
    "updated": "2026-10-19",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "template": true,
    "target": "button",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "targetText": "保存",
    "anchorVersion": 2
  },
  {
    "id": "responsibility-area:system:07",
    "context": "responsibility-area:import:type",
    "page": "责任区域管理.html",
    "title": "部门与人员导入",
    "body": "支持导入部门管辖、人员管辖，默认合并策略；上传后解析并预览，可仅看错误并下载错误明细。部门名称须匹配已有部门；人员需匹配所属部门与姓名，重名需手机号；人员方式为跟随部门或独立配置。跟随部门时楼栋/楼层/区域应留空；独立配置按有效场所层级解析。单次最多2000行。全部错误修正后才能确认导入，失败不更新已保存范围。切换导入类型或关闭清空本次预览。",
    "updated": "2026-10-19",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "template": true,
    "target": ".n-upload,.n-upload-trigger",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "stats-reports:system:01",
    "context": "统计报表.html::page",
    "page": "统计报表.html",
    "title": "查询范围与筛选",
    "body": "默认本月，可选今日、本周、本月、本季度或自定义时间范围；按报警发生时间筛选，跨度不超过一年。责任区域、违规事件类型、报警等级可清空；重置恢复本月并清空这三项筛选。",
    "updated": "2026-10-20",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".st-filter",
    "point": {
      "rx": 0.55,
      "ry": 0.13
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "stats-reports:system:02",
    "context": "统计报表.html::page",
    "page": "统计报表.html",
    "title": "指标口径与无样本",
    "body": "识别准确率＝确认违规÷（确认违规＋误报），排除待复核和计划内事件；复核率＝已复核÷报警总量；查处闭环率＝已完成处置÷确认违规。无有效分母显示“—”，合计按全部记录重算，不平均百分比。",
    "updated": "2026-10-20",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".st-metric",
    "point": {
      "rx": 0.7,
      "ry": 0.2
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "stats-reports:system:03",
    "context": "统计报表.html::page",
    "page": "统计报表.html",
    "title": "统计下钻与返回",
    "body": "点击指标、排行或明细入口后携带当前时间范围和对应记录跳转报警复核或查处管理。来源筛选、Tab及统计维度保存在当前浏览器会话，点击返回恢复来源。统计演示明细仅供查看，不写入业务台账。",
    "updated": "2026-10-20",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".st-metric",
    "point": {
      "rx": 0.5,
      "ry": 0.6
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "stats-analysis:system:01",
    "context": "数据分析.html::page",
    "page": "数据分析.html",
    "title": "查询范围与筛选",
    "body": "默认本月，可选今日、本周、本月、本季度或自定义时间范围；按报警发生时间筛选，跨度不超过一年。责任区域、违规事件类型、报警等级可清空；重置恢复本月并清空这三项筛选。",
    "updated": "2026-10-20",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".st-filter",
    "point": {
      "rx": 0.55,
      "ry": 0.13
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "stats-analysis:system:02",
    "context": "数据分析.html::page",
    "page": "数据分析.html",
    "title": "指标口径与无样本",
    "body": "识别准确率＝确认违规÷（确认违规＋误报），排除待复核和计划内事件；复核率＝已复核÷报警总量；查处闭环率＝已完成处置÷确认违规。无有效分母显示“—”，合计按全部记录重算，不平均百分比。",
    "updated": "2026-10-20",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".st-metric",
    "point": {
      "rx": 0.7,
      "ry": 0.2
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "stats-analysis:system:03",
    "context": "数据分析.html::page",
    "page": "数据分析.html",
    "title": "统计下钻与返回",
    "body": "点击指标、排行或明细入口后携带当前时间范围和对应记录跳转报警复核或查处管理。来源筛选、Tab及统计维度保存在当前浏览器会话，点击返回恢复来源。统计演示明细仅供查看，不写入业务台账。",
    "updated": "2026-10-20",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".st-metric",
    "point": {
      "rx": 0.5,
      "ry": 0.6
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "stats-reports:system:04",
    "context": "统计报表.html::page",
    "page": "统计报表.html",
    "title": "报表分组与合计",
    "body": "报警报表与查处报表通过Tab切换；支持按日期、区域、违规事件类型、等级分组，查处报表另支持按违规人员。表格展示全部分组及全部筛选结果合计，查处范围仅含确认违规记录。行内及合计查看明细均按对应记录下钻。",
    "updated": "2026-10-20",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".st-table-shell .st-table-head",
    "point": {
      "rx": 0.3,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "stats-reports:system:05",
    "context": "统计报表.html::page",
    "page": "统计报表.html",
    "title": "导出与排行",
    "body": "导出生成Excel文件，不同统计维度各为一个工作表；无分组时导出禁用。确认违规区域排行按违规数量，违规人员排行使用登记的违规人员，不以处置人替代。",
    "updated": "2026-10-20",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": "button",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "targetText": "导出报表",
    "anchorVersion": 2
  },
  {
    "id": "stats-analysis:system:04",
    "context": "数据分析.html::page",
    "page": "数据分析.html",
    "title": "报警趋势与结果分布",
    "body": "展示每日报警总量和确认违规数量趋势；复核结果按确认违规、误报、计划内事件、待复核展示数量与占比。违规类型排行同时显示识别准确率，区域排行按确认违规数量排序。",
    "updated": "2026-10-20",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".st-card-head",
    "point": {
      "rx": 0.6,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "targetText": "报警与确认违规趋势",
    "anchorVersion": 2
  },
  {
    "id": "stats-analysis:system:05",
    "context": "数据分析.html::page",
    "page": "数据分析.html",
    "title": "识别准确率趋势",
    "body": "单独一张图展示每日识别准确率，与处置闭环率趋势上下排列，不将两种不同业务口径叠加比较。绘图区随卡片宽度自适应，日期刻度按可用宽度均匀增加；数据点提示日期、准确率、确认违规量、误报量和有效样本量。无有效样本日期不画比率点，不以零代替。",
    "updated": "2026-10-20",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".st-card-head",
    "point": {
      "rx": 0.6,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "targetText": "识别准确率趋势",
    "anchorVersion": 2
  },
  {
    "id": "stats-analysis:system:06",
    "context": "数据分析.html::page",
    "page": "数据分析.html",
    "title": "处置闭环率趋势",
    "body": "单独一张图展示处置闭环率，沿用相同时间及业务筛选。按报警发生日期归组，展示这些报警截至当前的完成比例；数据点提示日期、闭环率、已闭环量、确认违规量、待闭环量。近期报警可能仍在正常处置周期内，不能只凭曲线下降判定处置效率下降；无确认违规不画比率点。",
    "updated": "2026-10-20",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".st-card-head",
    "point": {
      "rx": 0.6,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "targetText": "处置闭环率趋势",
    "anchorVersion": 2
  },
  {
    "id": "stats-analysis:system:07",
    "context": "数据分析.html::page",
    "page": "数据分析.html",
    "title": "智能分析与行动建议",
    "body": "智能分析根据当前查询范围显示中文场景说明。没有报警时显示暂无数据；没有待复核时不再要求复核；确认违规全部完成时明确已全部闭环，但仍有待复核则继续提醒。01说明接收处置，02说明区域分布，03说明复核与样本。每个场景的标题、正文和按钮详见本页场景标注及说明书4.10节，不使用字母条件公式。本次未修改页面分析逻辑。",
    "updated": "2026-10-24",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-24T18:00:05+08:00",
    "target": ".st-ai-heading",
    "point": {
      "rx": 0.75,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "alarm-center:system:stats-return",
    "context": "AI隐患核查.html::page",
    "page": "AI隐患核查.html",
    "title": "统计来源返回按钮",
    "body": "从统计页面下钻进入时才显示返回按钮；按钮位于“今日报警／全部报警”Tab所在行最右侧，不放在顶部页面标题之前。点击返回来源统计页并恢复已保存筛选。直接进入业务页不显示该返回按钮。",
    "updated": "2026-10-20",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T05:18:12.920525+00:00",
    "target": "#alarmScopeTabs button",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "返回"
  },
  {
    "id": "case-management:system:stats-return",
    "context": "隐患违章管理-违章查处.html::page",
    "page": "隐患违章管理-违章查处.html",
    "title": "统计来源返回按钮",
    "body": "从统计页面下钻进入时，返回按钮位于筛选条件卡片上方的独立操作行，靠右对齐，不放在顶部页面标题之前。点击返回来源统计页并恢复筛选。直接打开业务页不显示该返回按钮。",
    "updated": "2026-10-20",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T05:18:12.920527+00:00",
    "target": "#caseApp .case-stack > div:first-child button",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "返回"
  },
  {
    "id": "safety-reports:system:01",
    "context": "安全管理报告.html::page",
    "page": "安全管理报告.html",
    "title": "页面用途与入口",
    "body": "数据统计下的安全管理报告，用于按周期生成、预览、下载报告并管理自动生成开关。报告为生成时的冻结快照，后续业务数据变化不会改写已有报告。",
    "updated": "2026-10-20",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".st-header .st-title",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "safety-reports:system:02",
    "context": "安全管理报告.html::page",
    "page": "安全管理报告.html",
    "title": "周期自动生成",
    "body": "日报覆盖前一自然日，周报覆盖前一完整自然周（周一至周日），月报覆盖前一完整自然月。三个开关独立控制。文案统一为“开启后，页面在线时于每日 09:00 后自动生成。”并单独显示“当前状态：已开启／未开启”。",
    "updated": "2026-10-20",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".st-card .st-card-head",
    "point": {
      "rx": 0.65,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "safety-reports:system:03",
    "context": "安全管理报告.html::page",
    "page": "安全管理报告.html",
    "title": "自动执行与保存边界",
    "body": "仅页面打开时在09:00后检查，打开页面或开启开关后检查，并每分钟再次检查；同一类型、周期和数据来源只自动生成一次。页面关闭后暂停，并非后台定时服务，不保证09:00准点执行。设置及报告保存在当前浏览器。",
    "updated": "2026-10-20",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": null,
    "anchorVersion": 2
  },
  {
    "id": "safety-reports:system:04",
    "context": "安全管理报告.html::page",
    "page": "安全管理报告.html",
    "title": "报告记录与示例",
    "body": "报告列表展示名称、类型、统计周期、生成方式、生成时间和操作；支持名称搜索、类型筛选及分页。初始演示报告用于展示列表，不表示当前开关已经开启或真实后台曾执行。",
    "updated": "2026-10-20",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".st-table-shell .st-table-head",
    "point": {
      "rx": 0.4,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "safety-reports:system:05",
    "context": "safety-reports:generate:type",
    "page": "安全管理报告.html",
    "title": "生成报告",
    "body": "页面右上角生成报告打开弹窗，可选日报、周报、月报或自定义；预设类型自动填充相应完整周期。自定义周期须开始不晚于结束、不超过366天，结束不能晚于当前时间。生成成功保存快照并打开预览，失败保留输入并提示。",
    "updated": "2026-10-20",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "template": true,
    "target": ".n-base-selection",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "safety-reports:system:06",
    "context": "safety-reports:preview:reportId",
    "page": "安全管理报告.html",
    "title": "预览与下载",
    "body": "从记录预览打开对应报告快照，展示关键指标、与上一等长周期比较、重点区域、事件类型、分析建议及统计口径。关闭回到报告列表。下载报告生成可独立打开的HTML文件，采用保存时快照，不重新计算历史报告。",
    "updated": "2026-10-20",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "template": true,
    "target": ".st-report-preview,.n-card-header",
    "point": {
      "rx": 0.6,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "dashboard:system:01",
    "context": "首页.html::page",
    "page": "首页.html",
    "title": "首页信息总览",
    "body": "当前首页展示监控总数及在线情况、作业计划视频回传、作业前／作业中／作业后统计、疑似违章和隐患分析、违规与人员排行。页面现有数字和图表为原型演示，不代表真实园区实时数据；本轮仅补充说明，不改首页业务内容。",
    "updated": "2026-10-20",
    "source": "本轮用户确认及当前代码核对",
    "deleted": true,
    "system": true,
    "updatedAt": "2026-10-20T00:00:00.000Z",
    "target": ":scope",
    "offset": {
      "x": 18,
      "y": 145
    }
  },
  {
    "id": "dashboard:system:02",
    "context": "首页.html::page",
    "page": "首页.html",
    "title": "导航与业务入口",
    "body": "通过统一侧栏进入报警中心、查处管理、数据统计、责任区域管理、参数配置和报警处置移动端。各业务页独立打开对应HTML；未接入的演示区域不视为已实现业务功能。",
    "updated": "2026-10-20",
    "source": "本轮用户确认及当前代码核对",
    "deleted": true,
    "system": true,
    "updatedAt": "2026-10-20T00:00:00.000Z",
    "target": ":scope",
    "offset": {
      "x": 18,
      "y": 179
    }
  },
  {
    "id": "monitor-atlas:system:01",
    "context": "方案图册.html::page",
    "page": "方案图册.html",
    "title": "独立监测大屏",
    "body": "独立全屏深蓝监测布局，顶部显示平台、园区、当前日期时间、返回后台与全屏按钮。返回后台进入AI报警中心；全屏按钮申请或退出系统全屏。平台入口与品牌入口均进入本页。",
    "updated": "2026-10-22",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:45:31.659215+00:00",
    "target": ".mast .brand",
    "point": {
      "rx": 1,
      "ry": 0
    },
    "offset": {
      "x": 12,
      "y": -2
    },
    "anchorVersion": 2
  },
  {
    "id": "entry:system:01",
    "context": "index.html::page",
    "page": "index.html",
    "title": "平台入口",
    "body": "默认入口进入监测一张图独立监测大屏，保留进入平台链接。平台首页菜单及首页功能页面已移除；平台品牌入口同样进入监测一张图。",
    "updated": "2026-10-20",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": "a",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "monitor-atlas:system:02",
    "context": "方案图册.html::page",
    "page": "方案图册.html",
    "title": "园区鸟瞰与楼栋点位",
    "body": "园区鸟瞰底图仅显示楼栋点位，包含仓库、办公楼、发电间、叉车充电间及配套区域。点位显示楼栋名称和未完成报警数量；点击打开建筑概况，不直接打开设备。支持拖拽、缩放与复位；底图加载失败可重试。点位坐标及楼层布局为演示数据。",
    "updated": "2026-10-22",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".map-stage",
    "point": {
      "rx": 0.5,
      "ry": 0.42
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "monitor-atlas:system:03",
    "context": "方案图册.html::page",
    "page": "方案图册.html",
    "title": "设备类型与消防业务边界",
    "body": "消防设备与摄像机分别统计在线数和总数，离线与业务报警分别表达。消防报警只有待处置、已处置两种业务状态，仅提供详情，无接收、复核和处置填写入口；无报警等级，不参与等级筛选及等级优先排序。AI违规报警沿用复核、接收、处置规则。",
    "updated": "2026-10-22",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:45:31.659227+00:00",
    "target": ".equipment-health",
    "point": {
      "rx": 0.94,
      "ry": 0
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "monitor-atlas:system:04",
    "context": "方案图册.html::page",
    "page": "方案图册.html",
    "title": "鸟瞰筛选与范围",
    "body": "鸟瞰层只保留责任区域（楼栋楼层）树选择、重置和报警栏展开收起。已移除设备类型、违规事件类型、报警等级筛选；加载时清除这些旧选中值，避免隐藏条件继续过滤。选择楼层同步所属楼栋，重置恢复默认范围、今日全部报警与初始地图视图。",
    "updated": "2026-10-22",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:45:31.659230+00:00",
    "target": ".map-toolbar .n-tree-select,.map-toolbar .n-base-selection",
    "point": {
      "rx": 1,
      "ry": 0
    },
    "offset": {
      "x": -4,
      "y": -4
    },
    "anchorVersion": 2
  },
  {
    "id": "monitor-atlas:system:05",
    "context": "方案图册.html::page",
    "page": "方案图册.html",
    "title": "今日报警列表与滚动",
    "body": "右侧只展示今日报警，顶部总计、待核警、待处置指标可切换列表范围；待核警对应待复核，待处置包含待接收和待处置。搜索匹配报警ID、设备或事件。未完成优先；AI记录之间按等级比较，再按时间排序，消防不按等级比较。AI卡片显示等级和置信度；消防不显示等级。可暂停或继续滚动，悬停、聚焦、选中或打开详情时暂停。\n同摄像头、同来源事件类型在未结束期间合并信号，不反复新增事件；保留首次、最近时间与次数。AI核警确认违规才生成任务并发短信。\n同摄像头、同来源事件类型在未结束期间合并信号，不反复新增事件；保留首次、最近时间与次数。AI核警确认违规才生成任务并发短信。",
    "updated": "2026-10-24",
    "source": "用户2026年10月24日确认及最新版需求规格说明书",
    "checked": "2026-10-24",
    "system": true,
    "updatedAt": "2026-10-24T18:00:01+08:00",
    "target": ".right-side .section-head",
    "point": {
      "rx": 0.55,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "monitor-atlas:system:06",
    "context": "方案图册.html::page",
    "page": "方案图册.html",
    "title": "状态与页内操作",
    "body": "AI待复核打开本页复核弹窗；待接收先确认接收，保存接收人和时间后进入待处置；待处置打开本页处置表单。已处置、误报、计划内事件只提供详情。消防无论待处置或已处置均只提供详情，不触发AI操作。保存失败显示错误，已复核或已处置阻止重复提交。",
    "updated": "2026-10-22",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".event-actions",
    "point": {
      "rx": 0.72,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "monitor-atlas:system:07",
    "context": "方案图册.html::page",
    "page": "方案图册.html",
    "title": "楼栋概况与详情联动",
    "body": "楼栋点位打开建筑概况，显示消防与摄像机在线数、今日总报警、待核警、待处置及今日报警记录；消防记录包含待处置和已处置示例。点击记录打开对应报警详情；查看详情进入该楼栋楼层监测，返回单位鸟瞰回到鸟瞰视图。无法匹配设备的报警提示暂无设备位置。",
    "updated": "2026-10-22",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".building-pin",
    "point": {
      "rx": 0.75,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "targetText": "2号仓库",
    "anchorVersion": 2
  },
  {
    "id": "monitor-atlas:system:08",
    "context": "monitor-atlas:device:deviceId",
    "page": "方案图册.html",
    "title": "楼层设备与监测值",
    "body": "楼层监测显示当前楼栋、一层至各楼层及屋顶切换、2.5D演示平面、左侧设备分类与当前楼层报警。分类为独立式电气火灾监控探测器、水压监测装置、摄像头，统计在线与离线。分类按钮筛选点位；点击设备显示名称、编号、类型、区域、在线状态和实时监测演示值。摄像机未接入直播时明确提示；支持平面拖拽、缩放和复位。",
    "updated": "2026-10-22",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "template": true,
    "target": ".fields",
    "point": {
      "rx": 0.5,
      "ry": 0.1
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "monitor-atlas:system:09",
    "context": "monitor-atlas:event:alarmId",
    "page": "方案图册.html",
    "title": "报警详情分支",
    "body": "AI待复核、误报、计划内事件展示对应基本信息、照片、视频及复核结果；确认违规展示查处详情／处置记录双Tab，字段、结果和时间轴沿用查处管理。无视频资源时显示暂无可播放视频。消防使用独立只读详情：报警ID、名称、状态、时间、设备名称、设备编号、区域，无等级、复核和处置表单。关闭返回原视图，不改变业务数据。\n消防从消防管家同步最新状态，不进入本地AI核警、接收、处置及短信流程；未处置且超期可电话介入，电话不改状态，超期依据不能套用AI接收时限。真实同步尚待联调。\n消防从消防管家同步最新状态，不进入本地AI核警、接收、处置及短信流程；未处置且超期可电话介入，电话不改状态，超期依据不能套用AI接收时限。真实同步尚待联调。",
    "updated": "2026-10-24",
    "source": "用户2026年10月24日确认及最新版需求规格说明书",
    "checked": "2026-10-24",
    "system": true,
    "updatedAt": "2026-10-24T18:00:01+08:00",
    "template": true,
    "target": ".info-title",
    "point": {
      "rx": 0.7,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "monitor-atlas:system:10",
    "context": "方案图册.html::page",
    "page": "方案图册.html",
    "title": "视图保存与跨页兼容",
    "body": "当前大屏复核、接收与处置均在页内完成。浏览器会话保存范围、缩放偏移、侧栏、选中项等；重新加载或返回后读取共享报警最新状态，不匹配的选中项取消并提示。已有独立复核页与查处管理页保留携带报警ID和大屏来源参数的兼容入口，不作为当前大屏按钮的默认跳转。",
    "updated": "2026-10-22",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:45:31.659233+00:00",
    "target": ".mast-tools a",
    "point": {
      "rx": 1,
      "ry": 0
    },
    "offset": {
      "x": 0,
      "y": -8
    },
    "anchorVersion": 2
  },
  {
    "id": "monitor-atlas:system:11",
    "context": "方案图册.html::page",
    "page": "方案图册.html",
    "title": "原型与数据边界",
    "body": "园区设备、报警、楼层位置、读数与视频表现为原型演示，使用当前浏览器共享存储，不代表真实消防主机、视频流、后台推送或权限服务。消防完成状态可来自报警状态或已有完成记录；楼层历史报警不提供写操作。截图本次未刷新，阅读页不使用示意图冒充页面截图。",
    "updated": "2026-10-22",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": null,
    "anchorVersion": 2
  },
  {
    "id": "alarm-review:system:map-return",
    "context": "AI识别的违章复核.html::page",
    "page": "AI识别的违章复核.html",
    "title": "监测大屏兼容来源复核",
    "body": "保留携带报警ID及大屏来源参数的兼容入口，加载记录并提供返回监测一张图。结果、事件类型和等级按分支校验，误报必选原因；提交确认后写入浏览器共享记录并返回，失败保留输入，已复核阻止重复提交。当前大屏复核默认在大屏页内弹窗完成。",
    "updated": "2026-10-22",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T05:18:12.920529+00:00",
    "target": "a",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "返回监测一张图"
  },
  {
    "id": "case-management:system:map-return",
    "context": "隐患违章管理-违章查处.html::page",
    "page": "隐患违章管理-违章查处.html",
    "title": "监测大屏兼容来源接收与处置",
    "body": "保留带报警ID及大屏来源参数的兼容入口：按ID筛选并打开记录，已完成只允许详情，待接收确认后接收，已接收可填写处置。返回大屏恢复已保存视图并重读状态；当前大屏按钮使用本页内接收确认和处置弹窗，表单规则复用查处管理。",
    "updated": "2026-10-22",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T05:18:12.920530+00:00",
    "target": "a",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "返回监测一张图"
  },
  {
    "id": "monitor-atlas:system:12",
    "context": "方案图册.html::page",
    "page": "方案图册.html",
    "title": "园区概况与七日趋势",
    "body": "左侧园区安全概况按全园设备统计总数、在线率、离线数和存在未完成报警的建筑数；消防设备与摄像机分别显示在线／总数、在线率进度和离线数。七日趋势按连续七个自然日统计报警量，展示累计与今日数量；不随局部楼栋筛选变为局部统计。",
    "updated": "2026-10-22",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:45:31.659235+00:00",
    "target": ".trend-panel",
    "point": {
      "rx": 0.94,
      "ry": 0
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "monitor-atlas:system:13",
    "context": "monitor-atlas:dialog:13",
    "page": "方案图册.html",
    "title": "大屏复核弹窗",
    "body": "来源为AI待复核报警的复核按钮，在当前页打开。上方显示报警ID、事件类型、时间、设备、置信度、等级、区域、责任人、复核超期；左右展示演示视频和违规照片。结果必选误报、确认违规或计划内事件；误报必选有效误报类型，确认违规必选事件类型与等级，备注选填最多200字。确认提交后保存并刷新；取消不保存，失败保留输入。视频进度属于原型演示。",
    "updated": "2026-10-22",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "template": true,
    "target": ".review-result-block label",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "monitor-atlas:system:14",
    "context": "monitor-atlas:dialog:14",
    "page": "方案图册.html",
    "title": "大屏处置表单与历史",
    "body": "来源为AI待处置报警，复用查处管理表单顺序和布局，不额外插入报警基本信息及现场照片。依次为选择违规人员、历史违规记录、处理结果、上传处理照片。人员必选，姓名与手机号作为选项；历史排除当前事件，显示历史次数、最后一次时间与类型、违规类型分布条形图。描述、整改措施均必填且最多500字；照片最多3张、每张2MB、仅图片。提交先校验并确认，保存后刷新列表，失败保留输入；取消关闭。\n违规人员与查处管理一致：内部／外来人员切换清空此前选择。内部人员通过组织树及姓名搜索，在人员表中单选，确认才回填，关闭不修改原值；外来人员填写姓名（最多30字）与11位有效手机号。历史按人员身份区分同名及内外部人员，排除当前事件；保存包含人员类型和外来人员信息。",
    "updated": "2026-10-22",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-24T18:00:06+08:00",
    "template": true,
    "target": ".case-section-title",
    "point": {
      "rx": 0.65,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "targetText": "处理结果",
    "anchorVersion": 2
  },
  {
    "id": "monitor-atlas:system:15",
    "context": "monitor-atlas:dialog:15",
    "page": "方案图册.html",
    "title": "楼层报警与消防详情层级",
    "body": "当前楼层报警列表支持定位对应点位，AI按阶段提供详情／复核／接收／处置，消防仅详情。消防未完成显示待处置，完成显示已处置，不显示报警等级及置信度。消防详情挂载至页面最外层并置于顶部栏之上，遮罩与详情不受楼层容器层级裁剪；关闭或Esc返回原楼层。切换楼层更新设备、报警和异常计数，设备在线状态与报警业务状态分别展示。",
    "updated": "2026-10-22",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "template": true,
    "target": ".section-head h2",
    "point": {
      "rx": 0.7,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "sample-library:system:01",
    "context": "样本库.html::page",
    "page": "样本库.html",
    "title": "样本来源与分类",
    "body": "样本库只收录AI来源、已复核、结果为确认违规或误报且复核时间有效的报警。确认违规为正样本，误报为负样本；消防、待复核、计划内事件排除。消防即使带有旧确认违规字段也不得收录。",
    "updated": "2026-10-22",
    "source": "用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".sample-tabs",
    "point": {
      "rx": 0.3,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "sample-library:system:02",
    "context": "样本库.html::page",
    "page": "样本库.html",
    "title": "查询与分页",
    "body": "Tab分为全部样本、正样本、负样本。筛选事件类型、复核完成时间起止和关键词，关键词匹配识别设备、责任区域、事件编号。点击查询或关键词回车后生效，重置清空条件；Tab或查询变化回到第1页，每页12条，按复核时间倒序。",
    "updated": "2026-10-22",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".sample-filters",
    "point": {
      "rx": 0.55,
      "ry": 0.15
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "sample-library:system:03",
    "context": "样本库.html::page",
    "page": "样本库.html",
    "title": "样本卡片",
    "body": "每张卡片展示报警照片、正负样本标签、事件类型、识别设备、责任区域、复核完成时间与事件编号；负样本补充误报类型，缺失显示未填写。无命中显示空态，调整筛选后可重查。",
    "updated": "2026-10-22",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".sample-card:first-child .sample-info h3",
    "point": {
      "rx": 0.75,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "sample-library:system:04",
    "context": "sample-library:dialog:preview",
    "page": "样本库.html",
    "title": "图片预览弹窗",
    "body": "来源为样本卡片照片，点击打开当前设备与样本类型标题的图片预览；照片保持比例，关闭返回原列表和查询条件，不修改样本。",
    "updated": "2026-10-22",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "template": true,
    "target": ".sample-preview",
    "point": {
      "rx": 0.5,
      "ry": 0.15
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "sample-library:system:05",
    "context": "样本库.html::page",
    "page": "样本库.html",
    "title": "一键导出所有图片",
    "body": "导出当前Tab和已应用筛选命中的全部图片，跨越当前分页，打包为ZIP。文件名由设备、事件类型、样本类别组成，非法字符清理、重名追加序号。无记录时禁用，导出中显示加载并防重复点击；成功提示图片数，读取失败显示原因及网页服务打开建议。file协议可能无法读取图片，不宣称导出成功。",
    "updated": "2026-10-22",
    "source": "本轮用户确认及当前代码核对",
    "checked": "2026-10-22",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".sample-heading button",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "case-management:system:fire-readonly",
    "context": "case-management:dialog:fire",
    "page": "隐患违章管理-违章查处.html",
    "title": "消防管家状态同步与电话介入",
    "body": "消防只读同步消防管家的最新待处置／已处置状态及可用更新时间；不核警、不生成本地任务、不发送AI处置短信、不提供接收或处置提交。仍未处置且超期才支持电话介入，联系对象／内容／结果必填，分别最多30／500／100字；记录值守人员及时间，不修改外部状态，不写AI接收处置。已处置仅查看历史电话。超期依据未提供时显示待确认，不套AI时限；同步异常保留最近已知状态及时间，不冒充实时。真实接口尚待接入。",
    "updated": "2026-10-24",
    "source": "用户2026年10月24日确认及最新版需求规格说明书",
    "system": true,
    "updatedAt": "2026-10-24T18:00:01+08:00",
    "template": true,
    "target": ".case-section-title",
    "point": {
      "rx": 0.65,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "targetText": "电话介入记录",
    "anchorVersion": 2,
    "checked": "2026-10-24"
  },
  {
    "id": "case-management:system:source-filter",
    "context": "隐患违章管理-违章查处.html::page",
    "page": "隐患违章管理-违章查处.html",
    "title": "来源判定与状态隔离",
    "body": "明确AI识别和消防设备来源。旧消防演示携带的复核、等级或处置字段不作为本地业务资格；显示外部报警状态，不允许旧本地AI处置记录覆盖。AI烟雾、焰火、消防通道堵塞等事件按AI来源继续走复核处置。",
    "updated": "2026-10-22",
    "source": "用户确认及当前代码核对",
    "system": true,
    "updatedAt": "2026-10-22T04:43:21.257832+00:00",
    "target": ".case-filters > div:first-child .n-base-selection",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "responsibility-area:system:sms-template",
    "context": "责任区域管理.html::page",
    "page": "责任区域管理.html",
    "title": "AI处置短信原文",
    "body": "【短信签名】您管辖区域有一条经核警确认的违规报警：{事件类型}，等级：{报警等级}，位置：{所属区域}，摄像头：{摄像头名称}，时间：{报警时间}。请及时接收并处置：{小程序链接}。\n仅AI核警确认违规触发，向全部匹配安管人员逐人发送。报警等级取最终等级，所属区域为完整路径，报警时间取首次报警；签名采用获准实际值。小程序链接校验身份权限，首位成功接收人锁定处置，其他人员只读。消防不发处置短信。真实短信服务尚未接入。",
    "updated": "2026-10-24",
    "source": "用户确认短信原文及最新版需求规格说明书",
    "checked": "2026-10-24",
    "system": true,
    "updatedAt": "2026-10-24T04:00:14.578395+00:00",
    "target": ".ra-people .ra-section-title",
    "point": {
      "rx": 0.6,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "specification-hub:system:01",
    "context": "规格说明书.html::page",
    "page": "规格说明书.html",
    "title": "需求规格说明书入口",
    "body": "一级菜单规格说明书位于报警处置移动端下方，点击进入资料入口页；需求规格说明书入口在新标签页打开最新版HTML评审稿。",
    "target": ".document-card:first-child .document-link",
    "system": true,
    "updatedAt": "2026-10-24T18:00:01+08:00",
    "updated": "2026-10-24",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "specification-hub:system:02",
    "context": "规格说明书.html::page",
    "page": "规格说明书.html",
    "title": "业务流程图入口",
    "body": "业务流程图入口在新标签页打开既有AI报警与消防设备报警业务流程图V2。该图为既有图像，后续新规则以最新版说明书为准，本次未重绘流程图。",
    "target": ".document-card:nth-child(2) .document-link",
    "system": true,
    "updatedAt": "2026-10-24T18:00:01+08:00",
    "updated": "2026-10-24",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "field-mobile-refresh",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "刷新任务",
    "body": "重新读取任务、接收、处置及电话记录，更新列表；不会自动接收任务或提交结果。",
    "target": "button[aria-label=\"刷新任务\"]",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "field-mobile-identity",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "当前处置人员",
    "body": "显示当前人员姓名与角色；当前为演示账号张安全。正式系统按登录身份及责任区域范围授权，不以页面显示姓名代替身份认证。",
    "target": ".welcome .small",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "field-mobile-total",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "待办总数",
    "body": "本人待接收与待处置合计，已处置不计；点击切换全部未完成任务。统计按本人任务全量计算，不随关键词命中数量缩小。",
    "target": ".summary button",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "待办总数"
  },
  {
    "id": "field-mobile-pending",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "待接收统计",
    "body": "显示可由当前人员接收且尚无人成功接收的任务数；点击筛选待接收任务。正式系统首位成功接收者锁定，其他收件人只查看。",
    "target": ".summary button",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "待接收"
  },
  {
    "id": "field-mobile-processing",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "待处置统计",
    "body": "显示本人成功接收但尚未完成的任务；点击筛选。其他人成功接收的任务不计入本人处置待办。",
    "target": ".summary button",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "待处置"
  },
  {
    "id": "field-mobile-search",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "摄像头及报警关键词",
    "body": "实时匹配报警ID、事件类型、责任区域、设备和原责任人；可与等级及任务状态组合，清空恢复当前范围。",
    "target": ".search .n-input",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "field-mobile-tabs",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "任务状态Tab",
    "body": "全部仅包含待接收、待处置，不包含已处置；切换Tab筛选列表，完成记录通过底部处置记录进入。",
    "target": ".main > .tabs button",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "全部"
  },
  {
    "id": "field-mobile-level-filter",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "报警等级筛选",
    "body": "下拉一级至四级，可清空为全部等级，与关键词及状态组合；只筛AI报警，不包含消防。",
    "target": ".list-meta .n-base-selection",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "field-mobile-count",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "列表命中数量",
    "body": "展示当前搜索、等级及状态条件下的任务／处置记录条数，与上方本人全量待办统计分别表达。",
    "target": ".list-meta > .small",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "field-mobile-event-level",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "卡片报警等级",
    "body": "一级最高、四级最低；使用事件类型与摄像头配置中较高者，未配置摄像头等级时沿用事件类型。标注以首张可见卡片为例，适用其他卡片。",
    "target": ".task .task-title > .pill:first-child",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "field-mobile-type",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "卡片事件类型",
    "body": "展示核警确认的违规事件类型；仅AI确认违规进入处置，误报、计划内事件及消防不进入本任务列表。",
    "target": ".task-title h3",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "field-mobile-status",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "卡片处置状态",
    "body": "待接收：无人有效接收；待处置：已接收未完成；已处置：存在有效完成结果。状态决定卡片按钮。",
    "target": ".task-title > .pill:last-child",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "field-mobile-photo",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "卡片报警照片",
    "body": "现场证据缩略图，点击放大查看，关闭预览返回原列表；查看图片不会接收任务。",
    "target": ".task-body .thumb",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "field-mobile-area",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "卡片责任区域",
    "body": "报警摄像头所在区域，用于定位现场，并按责任区域管理解析通知及候选接收人员；名称不等于处置人。",
    "target": ".task-info p:first-child",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "field-mobile-device",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "卡片摄像头名称",
    "body": "显示产生报警的摄像头，结合责任区域定位现场；同摄像头同来源事件类型在未结束期间信号合并。",
    "target": ".task-info p:nth-child(2)",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "field-mobile-time",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "卡片报警时间",
    "body": "显示首次报警发生时间，后续合并信号不覆盖它；通知、复核、接收及完成时间为不同节点。",
    "target": ".task-info > span",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "field-mobile-timing",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "接收及超期提示",
    "body": "未接收提示及时接收，不累计处置超期；有效接收后按基础配置显示剩余或超期时间，默认1800秒，等于不超期。",
    "target": ".task-foot > .small",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "field-mobile-open-accept",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "查看并接收",
    "body": "进入该报警详情查看现场及信息；此按钮本身不直接接收，需在详情点击接收处置任务并确认。首位成功接收者为唯一主要负责人及最终处置人。",
    "target": ".task-foot button",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "查看并接收"
  },
  {
    "id": "field-mobile-open-process",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "去处置",
    "body": "进入已接收任务详情，再通过填写处置结果进入表单；正式权限仅限锁定接收人，其他收件人员只读。",
    "target": ".task-foot button",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "去处置"
  },
  {
    "id": "field-mobile-open-result",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "查看结果",
    "body": "打开已完成任务，查看实际处置人、完成时间、处置经过、整改及照片；不可重复接收或提交。",
    "target": ".task-foot button",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "查看结果"
  },
  {
    "id": "field-mobile-nav-tasks",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "底部处置任务",
    "body": "返回任务列表，仅显示当前身份有权处理的未完成AI任务；正式系统他人已接收的任务只查看进度。",
    "target": "nav.bottom > button",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "处置任务"
  },
  {
    "id": "field-mobile-nav-records",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "底部处置记录",
    "body": "切换本人已完成记录，支持关键词与等级筛选，点击查看结果；不把已处置继续计入待办。",
    "target": "nav.bottom > button",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "处置记录"
  },
  {
    "id": "field-mobile-empty",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "列表空态",
    "body": "无任务或无匹配记录时展示提示；有条件时引导调整搜索／等级，无条件时等待通知，不生成假任务。",
    "target": ".main > .empty",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "field-mobile-back",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "返回操作",
    "body": "返回上一页面；填写表单时先按现有逻辑保存草稿再返回，不等于提交或完成。",
    "target": "button[aria-label=\"返回\"]",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "field-mobile-detail-accept",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "详情接收按钮",
    "body": "点击发起接收确认，取消不写入；确认成功记录人员及接收时间并开始计时。正式系统多人同时接收仅一人成功，其他人只读。",
    "target": "footer.bottom button",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "接收处置任务"
  },
  {
    "id": "field-mobile-detail-process",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "填写处置结果",
    "body": "进入处置表单，需本人已成功接收且任务未完成；处置人沿用锁定接收人，其他收件人无编辑权限。",
    "target": "footer.bottom button",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "填写处置结果"
  },
  {
    "id": "field-mobile-save-draft",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "保存草稿",
    "body": "保存当前填写内容便于返回继续，草稿不是处置结果，不改变待处置状态，也不计入完成统计。",
    "target": "footer.bottom button",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "保存草稿"
  },
  {
    "id": "field-mobile-submit",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "提交处置",
    "body": "必填：违规人员、处理经过、整改措施；图片读取完成且校验通过后确认提交。只允许锁定接收人提交，失败保留输入，成功唯一完成并显示回执。",
    "target": "footer.bottom button",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "提交处置"
  },
  {
    "id": "field-mobile-description",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "处理经过描述",
    "body": "必填，去首尾空白后不可为空，最多500字；描述现场核实、沟通、安全教育等实际处理过程。",
    "target": "textarea[placeholder=\"请填写现场核实、沟通、安全教育等处理经过\"]",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "field-mobile-measures",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "整改措施",
    "body": "必填，去首尾空白后不可为空，最多500字；记录已落实整改及现场恢复情况。",
    "target": "textarea[placeholder=\"请填写已落实的整改措施及现场恢复情况\"]",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "field-mobile-evidence",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "处理照片上传",
    "body": "选填，最多3张，每张不超过2MB，支持JPEG、PNG、WebP；可预览、删除，读取中禁止提交；静态原型不等于文件已上传服务器。",
    "target": ".panel .n-upload",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "field-pc-column-1",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "报警来源字段",
    "body": "区分AI识别与消防设备，依据可信来源字段和设备关联，不根据事件名称猜测。",
    "target": ".case-table thead th",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "报警来源"
  },
  {
    "id": "field-pc-column-2",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "处置状态字段",
    "body": "AI为待接收／待处置／已处置；消防只同步消防管家的待处置／已处置，不执行本地接收提交。",
    "target": ".case-table thead th",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "处置状态"
  },
  {
    "id": "field-pc-column-3",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "处置人（责任人）字段",
    "body": "接收前可展示责任区域匹配的候选人员；首位成功接收后锁定唯一负责人及最终处置人，不能把违规人员当作处置人。",
    "target": ".case-table thead th",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "处置人（责任人）"
  },
  {
    "id": "field-pc-column-4",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "处置超期字段",
    "body": "AI从成功接收起计时，默认1800秒，严格大于才超期；未接收不计。消防超期取外部依据，不能套AI时限。",
    "target": ".case-table thead th",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "处置超期"
  },
  {
    "id": "field-pc-column-5",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "报警ID字段",
    "body": "唯一业务事件编号，用于关联核警、接收、处置和电话；合并信号不重复生成事件编号。",
    "target": ".case-table thead th",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "报警ID"
  },
  {
    "id": "field-pc-column-6",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "报警名称字段",
    "body": "展示事件类型，AI烟雾、焰火等仍按AI来源处理；消防同名不能混入AI任务。",
    "target": ".case-table thead th",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "报警名称"
  },
  {
    "id": "field-pc-column-7",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "报警时间字段",
    "body": "首次报警时间，用于时间查询及完整处置周期，合并信号不覆盖首次时间。",
    "target": ".case-table thead th",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "报警时间"
  },
  {
    "id": "field-pc-column-8",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "设备名称字段",
    "body": "来源摄像头或消防设备，结合所属区域定位现场。",
    "target": ".case-table thead th",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "设备名称"
  },
  {
    "id": "field-pc-column-9",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "置信度字段",
    "body": "AI识别置信度，仅展示来源提供值，不是人工核警结果；消防不适用。",
    "target": ".case-table thead th",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "置信度"
  },
  {
    "id": "field-pc-column-10",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "报警等级字段",
    "body": "AI一级最高、四级最低，取事件类型与摄像头配置中较高等级；消防无本地AI等级。",
    "target": ".case-table thead th",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "报警等级"
  },
  {
    "id": "field-pc-column-11",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "责任区域字段",
    "body": "设备所在楼栋／楼层／区域路径，和责任区域管理关联，用于匹配短信通知人员。",
    "target": ".case-table thead th",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "责任区域"
  },
  {
    "id": "field-pc-column-12",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "报警照片字段",
    "body": "AI现场照片可点击放大，不会改变状态；消防不填AI报警图片字段。",
    "target": ".case-table thead th",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "报警照片"
  },
  {
    "id": "field-pc-column-13",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "复核人字段",
    "body": "记录AI实际核警人员，不以当前登录人替代历史人员；消防不适用。",
    "target": ".case-table thead th",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "复核人"
  },
  {
    "id": "field-pc-column-14",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "复核时间字段",
    "body": "AI核警完成时间，与报警、通知、接收及完成时间分开；消防不适用。",
    "target": ".case-table thead th",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "复核时间"
  },
  {
    "id": "field-pc-column-15",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "复核超期字段",
    "body": "AI从首次报警到核警完成，未完成取当前时间，默认300秒，严格大于超期；消防不适用。",
    "target": ".case-table thead th",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "复核超期"
  },
  {
    "id": "field-pc-column-16",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "违规人员字段",
    "body": "处置登记的行为当事人，用于历史及统计，区别于负责人和核警人。",
    "target": ".case-table thead th",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "违规人员"
  },
  {
    "id": "field-pc-column-17",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "接收时间字段",
    "body": "首位成功接收任务的时间，作为AI处置计时起点；消防不生成本地接收记录。",
    "target": ".case-table thead th",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "接收时间"
  },
  {
    "id": "field-pc-column-18",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "处置时间字段",
    "body": "唯一有效完成结果的提交时间；未完成不编造，消防本地AI列不适用。",
    "target": ".case-table thead th",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "处置时间"
  },
  {
    "id": "field-pc-column-19",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "处置周期字段",
    "body": "首次报警至最终完成的整体时长，区别于接收后处置耗时；未完成显示占位。",
    "target": ".case-table thead th",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "处置周期"
  },
  {
    "id": "field-pc-detail",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "详情按钮",
    "body": "打开对应AI查处详情或消防只读详情。AI支持查处详情／处置记录，消防同步外部信息及电话记录；查看不改变状态。",
    "target": ".case-table tbody button",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "详情"
  },
  {
    "id": "field-pc-accept",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "接收处置按钮",
    "body": "仅AI确认违规且未接收、未完成时可发起接收确认。首位成功接收人锁定唯一负责人及最终处置人，其他人只读；取消不写入，服务端须保证并发仅一人成功。",
    "target": ".case-table tbody button",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "接收处置"
  },
  {
    "id": "field-pc-process",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "处置按钮",
    "body": "已接收未完成AI任务进入处置表单，正式权限仅锁定接收人可编辑提交；其他人员只能查看，消防无本地处置入口。",
    "target": ".case-table tbody [data-annotation-action=\"process\"]",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "处置"
  },
  {
    "id": "field-pc-phone",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "电话介入按钮",
    "body": "值守人员记录线下联系；AI支持催接收／催处置，消防仅未处置且超期时介入。必填联系对象、内容及结果，保存不代替处置、不改变消防状态，不自动拨号。",
    "target": ".case-table tbody button",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "电话介入"
  },
  {
    "id": "field-pc-more",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "候选处置人更多",
    "body": "展开查看责任区域匹配的候选人员及联系信息；匹配多人时全部收到短信，但首位成功接收后只有该人可处置。",
    "target": ".case-responsible-summary button",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "更多"
  },
  {
    "id": "field-pc-export",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "导出按钮",
    "body": "导出当前全部命中记录而非仅当前分页，保留来源及筛选；消防不输出AI专属字段。当前原型为CSV导出。",
    "target": ".case-table-top button",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "导出"
  },
  {
    "id": "field-pc-role",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "演示角色切换",
    "body": "切换值守人员／处置人员演示入口，电话入口按角色展示；演示切换不等于正式账号授权或服务端权限已实现。",
    "target": ".case-table-top .n-base-selection",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "field-pc-reset",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "重置筛选",
    "body": "清空既有查询条件，恢复默认范围，列表重新计算；不删除业务记录。",
    "target": ".case-filter-footer button",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "重置"
  },
  {
    "id": "field-pc-expand",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "展开／收起筛选",
    "body": "展开显示更多过滤条件，收起仅隐藏筛选项；查询含义按当前有效条件执行，不提交业务状态。",
    "target": ".case-filter-footer button",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "展开"
  },
  {
    "id": "field-pc-pagination",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "分页与每页数量",
    "body": "显示全部命中条数；切换页码查看另一页，可选择每页10／20／50条；仅改变展示，不改变统计口径或导出范围。",
    "target": ".case-pagination .n-pagination",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "field-pc-filter-1",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "报警来源筛选",
    "body": "可选AI识别／消防设备或清空为全部；切换清除不适用条件并回到第一页。",
    "target": ".case-filters > div",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "报警来源"
  },
  {
    "id": "field-pc-filter-2",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "报警时间筛选",
    "body": "按报警发生时间范围筛选，不用核警、接收或完成时间代替。",
    "target": ".case-filters > div",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "报警时间"
  },
  {
    "id": "field-pc-filter-3",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "报警名称筛选",
    "body": "按当前来源可用事件类型筛选，可清空。",
    "target": ".case-filters > div",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "报警名称"
  },
  {
    "id": "field-pc-filter-4",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "报警等级筛选",
    "body": "只筛AI一级至四级，消防模式隐藏，不让历史隐藏等级条件限制消防结果。",
    "target": ".case-filters > div",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "报警等级"
  },
  {
    "id": "field-pc-filter-5",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "处置状态筛选",
    "body": "按当前来源支持的业务状态筛选，消防不出现待接收。",
    "target": ".case-filters > div",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "处置状态"
  },
  {
    "id": "field-pc-filter-6",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "处置是否超期筛选",
    "body": "AI按接收至完成或当前时间与时限比较，未接收不计处置超期。",
    "target": ".case-filters > div",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "处置是否超期"
  },
  {
    "id": "field-pc-filter-7",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "责任区域筛选",
    "body": "按来源设备所在区域筛选，可清空恢复全部。",
    "target": ".case-filters > div",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "责任区域"
  },
  {
    "id": "field-pc-filter-8",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "复核是否超期筛选",
    "body": "只适用AI，按首次报警至核警计算，消防模式隐藏。",
    "target": ".case-filters > div",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "复核是否超期"
  },
  {
    "id": "field-pc-filter-9",
    "page": "隐患违章管理-违章查处.html",
    "context": "隐患违章管理-违章查处.html::page",
    "title": "关键词筛选",
    "body": "匹配报警ID、设备、责任区域、处置人、复核人及违规人员，可与其他筛选组合。",
    "target": ".case-filters > div",
    "system": true,
    "updatedAt": "2026-10-24T18:00:02+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "当前页面字段核对及最新确认需求",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "关键词"
  },
  {
    "id": "field-mobile-violator",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "违规人员选择",
    "body": "必选，可搜索姓名或手机号；选中后展示其历史违规次数、最近违规和类型分布，历史排除当前任务。违规人员是行为当事人，不是任务接收人或处置人。",
    "target": ".field .n-base-selection",
    "system": true,
    "updatedAt": "2026-10-24T18:00:03+08:00",
    "updated": "2026-10-24",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "field-mobile-return-list",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "返回列表",
    "body": "返回任务列表；查看详情不会完成任务，表单返回按草稿逻辑处理，列表保留当前业务状态。",
    "target": "footer.bottom button",
    "system": true,
    "updatedAt": "2026-10-24T18:00:03+08:00",
    "updated": "2026-10-24",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "返回列表"
  },
  {
    "id": "field-mobile-return-tasks",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "返回任务列表",
    "body": "完成回执或任务变更提示下返回列表，已完成任务不再进入待办。",
    "target": "button",
    "system": true,
    "updatedAt": "2026-10-24T18:00:03+08:00",
    "updated": "2026-10-24",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "返回任务列表"
  },
  {
    "id": "field-mobile-view-record",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "查看处置记录",
    "body": "切换该事件时间轴，查看通知、核警、接收、电话及完成记录；未发生节点不虚构时间，无编辑或提交效果。",
    "target": "footer.bottom button",
    "system": true,
    "updatedAt": "2026-10-24T18:00:03+08:00",
    "updated": "2026-10-24",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "查看处置记录"
  },
  {
    "id": "field-mobile-view-result",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "查看处置结果",
    "body": "完成回执进入该任务只读详情，显示负责人、完成时间和处置内容，不能再次提交。",
    "target": "footer.bottom button",
    "system": true,
    "updatedAt": "2026-10-24T18:00:03+08:00",
    "updated": "2026-10-24",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2,
    "targetText": "查看处置结果"
  },
  {
    "id": "field-mobile-video",
    "page": "报警处置移动端.html",
    "context": "报警处置移动端.html::page",
    "title": "报警视频片段",
    "body": "当前为现场图封面及居中播放图标的静态占位，无真实播放点击能力；不能标记为视频平台已接入。",
    "target": ".video-placeholder",
    "system": true,
    "updatedAt": "2026-10-24T18:00:03+08:00",
    "updated": "2026-10-24",
    "point": {
      "rx": 0.5,
      "ry": 0.5
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "stats-analysis:system:scenarios-scope",
    "page": "数据分析.html",
    "context": "数据分析.html::page",
    "title": "智能分析：阅读说明与优先提示",
    "body": "智能分析只分析当前查询范围内的AI报警，不包含消防报警。同一报警合并了多条信号，仍按一条报警统计，不因短信发给多人而增加报警数量。\n\n综合研判优先提醒尚未完成的处置超期任务，其次提醒超期待复核、普通待复核，再提醒未闭环任务。只有确实没有待复核和未闭环任务时，才使用全部完成或常态观察类提示。三张建议卡分别说明：01跟进任务接收和处置；02查看区域分布；03完成复核或核查样本。\n\n多个情况同时存在时，综合研判标题先突出最紧急的一项，正文补充其他实际情况，不能隐去剩余待办。例如，有超期待处置和待复核时，标题优先提示超期待处置，正文仍要说明还有多少条待复核。已全部闭环只指当前已经确认违规的记录，不代表尚未核实的报警也处理完了。\n\n正文中的数量全部来自当前查询结果。闭环率没有可计算的确认违规记录时显示“—”；准确率没有确认违规或误报样本时也显示“—”，不能当作零或百分之百。百分比通常保留一位小数；是否全部闭环按实际完成条数判断，不能因四舍五入显示百分之百就说全部完成。\n\n以下是需求说明及文案规范；本次只调整文档与标注，页面尚未完成全部场景改造，不代表真实模型推理。\n本次是说明文案调整，页面分析逻辑尚待按场景实现，截图未重拍。",
    "target": ".st-ai-heading",
    "system": true,
    "updatedAt": "2026-10-24T18:00:05+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "本轮用户要求及需求规格说明书4.10节",
    "point": {
      "rx": 0.5,
      "ry": 0.12
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "stats-analysis:system:scenarios-conclusion",
    "page": "数据分析.html",
    "context": "数据分析.html::page",
    "title": "综合研判：无报警、无待复核及全部闭环",
    "body": "场景一：当前查询条件下，没有任何AI报警信息。\n\n综合研判标题：“当前筛选范围暂无AI报警记录”。\n\n正文：“当前查询条件下未查到AI报警记录。请调整时间、区域或其他筛选条件后查看；无报警记录不代表设备在线或现场无风险。”\n\n右侧分析记录、待闭环事件、未完成处置超期均显示零条，准确率和闭环率显示“—”。01、02、03三张建议卡不显示，也不出现查看空任务的按钮。某个区域或设备关联范围没有报警时，同样适用；不能据此说设备运行正常或现场绝对安全。\n\n场景二：待复核为零条，所有报警都已经复核，但还有任务没有完成。\n\n综合研判必须说明“当前筛选范围内报警已全部复核”，不再提示“请先完成待复核”。\n\n如果有尚未完成的处置超期任务，标题：“建议优先推动超期待处置记录闭环”。如果没有处置超期，但还有待接收，标题：“建议及时接收任务并推进处置闭环”。如果任务都已接收、尚未完成但也未超期，标题：“当前未闭环任务尚未超期，请按时完成处置”。\n\n正文：“当前筛选范围内报警已全部复核。确认违规{确认违规条数}条，已闭环{已闭环条数}条，待闭环{待闭环条数}条，其中待接收{待接收条数}条、待处置{待处置条数}条。”再补充实际闭环率和是否存在处置超期。\n\n01根据实际情况显示优先处理超期、及时接收或按时处置，使用场景六至八的对应文案。02根据实际确认违规区域显示，使用后述区域场景。03有误报时显示“复查误报场景”；没有误报但有确认违规时显示“保持复核质量”，不能继续显示“查看待复核”。\n\n场景三：确认违规已经全部完成处置，闭环率百分之百，并且没有待复核。\n\n综合研判标题：“当前确认违规已全部闭环，建议持续巡查”。\n\n正文：“当前筛选范围内报警已全部复核，{确认违规条数}条确认违规已全部闭环，闭环率100%。建议持续检查整改保持情况，防止同类问题再次发生。”\n\n01标题：“当前确认违规已全部闭环”；提示：“已闭环{确认违规条数}条，闭环率100%”；建议：“复查整改结果并持续巡查，防止同类问题再次发生。”按钮：“查看已闭环”，只查看当前范围已完成的AI任务。\n\n02仍可说明历史确认违规较多的区域，但只能建议巡查和巩固整改，不能说这些记录仍待处置。03有误报时核查误报，没有误报时保持复核质量。不存在待办时，不再出现“查看未闭环”或“优先处理超期事件”。\n本次是说明文案调整，页面分析逻辑尚待按场景实现，截图未重拍。",
    "target": ".st-ai-conclusion",
    "system": true,
    "updatedAt": "2026-10-24T18:00:05+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "本轮用户要求及需求规格说明书4.10节",
    "point": {
      "rx": 0.5,
      "ry": 0.12
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "stats-analysis:system:scenarios-action01",
    "page": "数据分析.html",
    "context": "数据分析.html::page",
    "title": "01及综合提示：仍有复核或处置待办",
    "body": "场景四：当前已确认的违规全部闭环，但仍有报警没有复核。\n\n综合研判标题：“建议先完成待复核记录，明确后续处置需求”；如果待复核已超期，改为：“建议优先完成超期待复核记录”。\n\n正文：“当前{确认违规条数}条确认违规已全部闭环，闭环率100%；仍有{待复核条数}条报警待复核，核实后可能新增处置任务，不能认定全部报警已处理完成。”有超期待复核时补充具体条数。\n\n01显示“当前确认违规已全部闭环”，可查看已闭环记录；02按已确认违规的区域分布提示；03显示待复核或超期待复核建议。闭环率百分之百与仍需核警可以同时存在。\n\n场景五：存在待复核报警，目前还没有确认违规。\n\n综合研判标题：“建议先完成待复核记录，明确后续处置需求”；若待复核已超期，标题改为：“建议优先完成超期待复核记录”。\n\n正文：“当前有{待复核条数}条报警待复核，尚无确认违规记录，闭环率为‘—’。请核对原始画面与现场事实，确认违规后再生成处置任务。”\n\n01标题：“暂无待处置任务”；提示：“暂无确认违规，待复核{待复核条数}条”；建议：“先完成报警核实，仅确认违规后才生成处置任务。”按钮：“查看待复核”。\n\n02标题：“暂无确认违规区域”；建议：“暂不推荐重点违规区域，保持常态巡查并等待有效核警结论。”不显示区域下钻按钮。03显示对应的普通或超期待复核建议。不能把待复核先当作违规或误报。\n\n场景六：还有已接收、未完成且已经超过处置期限的任务。\n\n综合研判标题：“建议优先推动超期待处置记录闭环”。\n\n正文：“当前还有{未完成处置超期条数}条已接收任务超过处置期限，请优先跟进负责人和现场整改进展。”同时如实补充其他待接收、待处置、待复核条数。\n\n01标题：“优先处理超期事件”；提示：“仍有{未完成处置超期条数}条超期待处置”；建议：“优先联系已接收任务的负责人，核实现场整改进展并完成结果提交；其他人员可查看进度，由接收人负责处置。”按钮：“查看超期待处置”，只查看当前范围内已接收、未完成且超期的AI任务。\n\n02照常展示区域情况；03有待复核就提醒复核，没有待复核则按误报或有效样本情况提示。已经完成但历史上曾超期的记录，不属于这里的未完成超期任务。\n\n场景七：没有未完成处置超期，但还有任务尚未接收。\n\n没有待复核时，综合研判标题：“建议及时接收任务并推进处置闭环”。如果同时还有待复核，标题先突出复核，正文仍补充待接收情况。\n\n01标题：“及时接收待办任务”；提示：“{待接收条数}条待接收，{待处置条数}条待处置”；建议：“先核实责任区域并及时接收待办；已有接收人的任务由该人继续处置，不重复接收。”按钮：“查看待接收”。\n\n待接收尚未开始接收后处置计时，不能算作“接收后处置超期”。02按区域展示；03按复核及误报情况展示。\n\n场景八：所有未完成任务都已接收，还未超出处置期限。\n\n没有待复核时，综合研判标题：“当前未闭环任务尚未超期，请按时完成处置”。如有待复核，标题先提醒复核，正文补充处置尚未超期。\n\n01标题：“按时完成处置”；提示：“{待处置条数}条待处置，暂无未完成处置超期”；建议：“按处置时限推进现场整改并提交结果，当前不能据此判断处置超期。”按钮：“查看待处置”。\n\n02按区域展示；03按复核及误报情况展示。不因为闭环率还没达到百分之百，就直接认定处置效率下降。\n本次是说明文案调整，页面分析逻辑尚待按场景实现，截图未重拍。",
    "target": ".st-ai-strategy:nth-child(1)",
    "system": true,
    "updatedAt": "2026-10-24T18:00:05+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "本轮用户要求及需求规格说明书4.10节",
    "point": {
      "rx": 0.5,
      "ry": 0.12
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "stats-analysis:system:scenarios-action02",
    "page": "数据分析.html",
    "context": "数据分析.html::page",
    "title": "02区域建议：逐场景文案",
    "body": "场景十三：没有确认违规，或者确认违规都没有关联区域。\n\n没有确认违规时，02标题：“暂无确认违规区域”；提示：“当前无确认违规区域分布”；建议：“暂不推荐重点违规区域，保持常态巡查并等待有效核警结论。”无按钮。\n\n有确认违规但全部缺少所属区域时，02标题：“补全报警所属区域”；提示：“{区域缺失条数}条确认违规的区域待核实”；建议：“核实摄像头与责任区域关联，补齐区域后再开展排名，不能把‘未分配’当真实重点区域。”按钮：“查看区域待核实记录”，仅查看区域缺失的确认违规。\n\n场景十四：确认违规只分布在一个有效区域。\n\n02标题：“关注当前区域”；提示：“{区域名}有{区域确认违规条数}条确认违规，占确认违规{区域占比}”；建议：“当前数据仅覆盖一个有效区域，不能据此认定其相对其他区域风险更高；请检查现场措施和整改保持情况。”按钮：“查看区域记录”。\n\n场景十五：有多个区域，某一个区域确认违规数量最多。\n\n02标题：“关注违规记录较多区域”；提示：“{区域名}有{区域确认违规条数}条确认违规，占确认违规{区域占比}”；建议：“该区域确认违规记录数量最多，建议核查作业组织、防护措施及现场秩序；记录数量不等于风险率。”按钮：“查看区域记录”，只看该区域确认违规。\n\n场景十六：多个区域的确认违规数量并列最多。\n\n02标题：“关注并列较多区域”；提示：“{并列区域个数}个区域并列，每个{区域确认违规条数}条确认违规”；建议：“{区域名列表}的确认违规数量并列最多，建议逐区核查现场措施，不擅自选一个作为唯一重点。”按钮：“查看并列区域”，包含所有并列区域。\n\n区域排名只按确认违规条数，不能按总报警量排序。有部分确认违规缺少区域时，在有效区域建议后补充：“另有{区域缺失条数}条确认违规区域待核实，可能影响区域比较。”占比以全部确认违规为分母，缺失区域的记录也在分母内。\n\n并列区域名称较多时，按名称稳定排序，显示前三个及“等{并列区域个数}个区域”，点击仍查看完整集合。未约定高发阈值，不写“高风险”“异常集中”“显著上升”。即使全部闭环，02仍可用于巡查分析，但不称这些历史记录尚未处置。\n本次是说明文案调整，页面分析逻辑尚待按场景实现，截图未重拍。",
    "target": ".st-ai-strategy:nth-child(2)",
    "system": true,
    "updatedAt": "2026-10-24T18:00:05+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "本轮用户要求及需求规格说明书4.10节",
    "point": {
      "rx": 0.5,
      "ry": 0.12
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "stats-analysis:system:scenarios-action03",
    "page": "数据分析.html",
    "context": "数据分析.html::page",
    "title": "03复核建议：误报、计划内事件与样本",
    "body": "场景九：所有报警均已复核，存在误报，但没有确认违规。\n\n综合研判标题：“当前无确认违规，建议复查误报场景”。正文：“当前暂无确认违规记录，闭环率为‘—’；存在{误报条数}条误报，建议核查原始画面及现场条件。”如果还有计划内事件，一并如实说明。\n\n01标题：“暂无待处置任务”；建议：“保持常态巡查；误报及计划内事件不生成处置任务。”无操作按钮。02显示“暂无确认违规区域”，无按钮。03标题：“复查误报场景”；提示：“已全部复核，存在{误报条数}条误报”；建议：“结合误报样本核查画面、遮挡及场景变化，未经现场核验不直接调整识别策略。”按钮：“查看误报”。\n\n全部有效样本都是误报时准确率可以显示零，但不能仅据此断言算法失效。\n\n场景十：查询结果全部是计划内事件。\n\n综合研判标题：“当前记录均为计划内事件，建议持续巡查”。正文：“当前{计划内事件条数}条记录均已复核为计划内事件，无需生成处置任务；暂无可用于准确率及闭环率计算的有效样本，两项显示‘—’。”\n\n01显示“暂无待处置任务”，不显示按钮。02显示“暂无确认违规区域”，不显示按钮。03标题：“当前记录均为计划内事件”；提示：“{计划内事件条数}条计划内事件，无有效准确率样本”；建议：“保留计划依据和核警记录，持续观察场景变化；不生成处置任务，不作为误报样本。”按钮：“查看计划内事件”。\n\n场景十一：仍有待复核，需要确定03显示哪种提醒。\n\n有超期待复核时，03标题：“优先完成超期待复核”；提示：“{超期待复核条数}条复核已超期，共{待复核条数}条待复核”；建议：“先核对超期记录的原始画面与现场事实，形成可追溯结论，再安排其余复核。”按钮：“查看超期待复核”。\n\n没有超期待复核时，03标题：“完成待复核记录”；提示：“{待复核条数}条待复核，暂无待复核超期”；建议：“按复核时限核实原始画面与现场事实，确认违规后再生成处置任务。”按钮：“查看待复核”。\n\n即使同时存在历史误报，03也先提示完成复核，可在建议后补充“另有{误报条数}条历史误报，可在复核完成后核查。”按钮仍查看待复核，不跳到误报。已经复核但曾经超期的记录不能算当前超期待复核。\n\n场景十二：没有待复核，也没有误报，但有确认违规。\n\n03标题：“保持复核质量”；提示：“已全部复核，暂无误报，确认违规{确认违规条数}条”；建议：“继续抽查已确认违规证据与核警一致性；当前样本准确率100%，不代表算法永不误报，或所有报警已完成处置。”按钮：“查看确认违规”。\n\n如果没有待复核但存在误报，03改用场景九的误报文案；如果只有计划内事件，改用场景十。综合研判和01仍按实际处置进度显示，不能用准确率百分之百替代闭环率百分之百。\n本次是说明文案调整，页面分析逻辑尚待按场景实现，截图未重拍。",
    "target": ".st-ai-strategy:nth-child(3)",
    "system": true,
    "updatedAt": "2026-10-24T18:00:05+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "本轮用户要求及需求规格说明书4.10节",
    "point": {
      "rx": 0.5,
      "ry": 0.12
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "stats-analysis:system:scenarios-drill",
    "page": "数据分析.html",
    "context": "数据分析.html::page",
    "title": "异常场景、按钮及返回说明",
    "body": "场景十七：数据正在加载，或者查询条件无效。\n\n加载时显示：“正在分析当前查询范围…”。时间条件无效时显示：“请选择有效的时间范围后查看分析。”不输出旧的业务结论，不生成三张建议卡。\n\n场景十八：数据读取失败，或数量及状态不一致。\n\n读取失败显示：“分析数据加载失败，请重试。”按钮：“重试”，重新读取当前范围。数据缺失、状态冲突或无法判断关键时间时显示：“当前分析数据存在缺失或状态不一致，请核对数据后重试。”不把缺失数据当零，不生成业务建议或跳转。\n\n场景十九：点击建议按钮时，对应记录已经不存在。\n\n提示：“当前条件下暂无对应记录，请刷新分析。”保留查询条件，不跳到无关记录。所有下钻保留当前时间、区域、事件类型及等级；返回分析页恢复当前查询，不能为查到数据而清空条件。\n\n查看超期待处置、待接收、待处置及已闭环，进入查处管理对应AI记录；查看待复核、超期待复核、误报、计划内事件、确认违规及区域记录，进入AI报警中心对应记录。零条目标不显示操作按钮，不能保留“查看零条待办”。查看并列区域时保留全部并列区域，不能扩大成全区域。\n\n综合研判右侧“分析记录”为当前全部AI报警数，“待闭环事件”为确认违规中尚未完成的任务数，“未完成处置超期”为已接收、尚未完成并超期的任务数。没有确认违规不能说全部闭环；没有超期不能说全部完成；只收到一条样本也不能概括全部算法表现。\n\n规则追溯：BR-28对应范围及异常反馈，BR-29对应综合研判文案，BR-30对应三张建议卡，BR-31对应下钻与返回。FR-123细化FR-105，要求按以上业务场景显示文案，不向用户展示字母变量、条件公式或内部场景代码。\n\n## 5 页面功能需求\n\n以下覆盖14个页面。每项FR的来源为对应原型有效标注；“当前实现”字样描述的是基线状态。详细验收结合第7节执行。AI页面、移动任务、样本和统计明细均受BR-14的来源隔离规则约束；查处管理按来源分支展示；旧演示记录具备复核字段不代表消防可纳入这些模块。\n\n### 5.1 平台入口\n\n原型页面：index.html\n本次是说明文案调整，页面分析逻辑尚待按场景实现，截图未重拍。",
    "target": ".st-ai-strategies .n-button",
    "system": true,
    "updatedAt": "2026-10-24T18:00:05+08:00",
    "updated": "2026-10-24",
    "checked": "2026-10-24",
    "source": "本轮用户要求及需求规格说明书4.10节",
    "point": {
      "rx": 0.5,
      "ry": 0.12
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "anchorVersion": 2
  },
  {
    "id": "monitor-atlas:system:violator-picker",
    "page": "方案图册.html",
    "context": "monitor-atlas:scope-editor:violator-picker",
    "template": true,
    "title": "选择违规人员",
    "body": "与查处管理相同的内部人员选择弹窗：左侧组织树可搜索部门或班组，选组织包含其下级部门；右侧按人员姓名搜索，表格展示姓名、账号、手机号、部门、班组、岗位，每页10人，单选。已选人员在顶部展示，可清除；确认回填，关闭放弃本次选择，重开带入当前已选值并重置搜索。外来人员不使用此弹窗，在处置表单填写姓名和手机号。",
    "target": ".case-person-layout",
    "point": {
      "rx": 0.5,
      "ry": 0.1
    },
    "offset": {
      "x": 0,
      "y": 0
    },
    "system": true,
    "updatedAt": "2026-10-24T18:00:06+08:00",
    "updated": "2026-10-24",
    "anchorVersion": 2
  }
];
